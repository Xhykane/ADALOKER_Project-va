const express = require('express');
const cors = require('cors');
const path = require('path');

// Import rute
const authRoutes = require('./routes/auth');
const generalRoutes = require('./routes/general');
const seekerRoutes = require('./routes/seeker');
const companyRoutes = require('./routes/companyDashboard');

const app = express();
const PORT = process.env.PORT || 3001; // Port untuk backend

// Middleware
app.use(cors()); // Mengizinkan request dari domain lain
app.use(express.json()); // Mem-parse body request JSON
app.use(express.urlencoded({ extended: true }));

// Middleware untuk menyajikan file statis dari folder 'uploads'
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Gunakan Rute
app.use('/api/auth', authRoutes);
app.use('/api', generalRoutes); // Rute publik seperti cari lowongan/perusahaan
app.use('/api/seeker', seekerRoutes); // Rute khusus pencari kerja (profil, dll)
app.use('/api/company', companyRoutes); // Rute khusus perusahaan (dashboard)

// Rute dasar untuk cek server
app.get('/', (req, res) => {
    res.send('Backend ADAloker sedang berjalan!');
});

app.listen(PORT, () => {
    console.log(`Server berjalan di http://localhost:${PORT}`);
});