const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const jwt = require('jsonwebtoken');

const dbPath = path.join(__dirname, '..', 'db.json');
const JWT_SECRET = 'your-very-secret-key';

// Helper untuk membaca DB
const readDb = () => {
    const data = fs.readFileSync(dbPath);
    return JSON.parse(data);
};

// Helper untuk menulis ke DB
const writeDb = (data) => {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
};

router.post('/login', (req, res) => {
    const { email, password, loginAs } = req.body;

    if (!email || !password || !loginAs) {
        return res.status(400).json({ message: 'Email, password, dan tipe login diperlukan.' });
    }

    const db = readDb();
    let user = null;

    if (loginAs === 'seeker') {
        user = db.users.find(u => u.email === email && u.password === password && u.role === 'seeker');
    } else if (loginAs === 'company') {
        user = db.companies.find(c => c.email === email && c.password === password && c.role === 'company');
    }

    if (!user) {
        return res.status(401).json({ message: 'Email atau password salah.' });
    }
    
    const payload = {
        user: {
            id: user.id,
            email: user.email,
            role: user.role
        }
    };

    jwt.sign(payload, JWT_SECRET, { expiresIn: '1h' }, (err, token) => {
        if (err) throw err;
        res.json({ token, user });
    });
});



router.post('/register', (req, res) => {
    const { fullName, email, password, role } = req.body;

    // 1. Validasi input dasar
    if (!fullName || !email || !password || !role) {
        return res.status(400).json({ message: 'Semua field wajib diisi.' });
    }

    const db = readDb();

    // 2. Cek apakah email sudah ada di database users atau companies
    const emailExists = db.users.some(u => u.email === email) || db.companies.some(c => c.email === email);
    if (emailExists) {
        return res.status(400).json({ message: 'Email sudah terdaftar. Silakan gunakan email lain.' });
    }

    // 3. Buat objek user/company baru
    if (role === 'seeker') {
        const newId = (db.users.length > 0 ? Math.max(...db.users.map(u => u.id)) : 0) + 1;
        const newUser = {
            id: newId,
            email: email,
            password: password, // Di aplikasi nyata, HARUS di-hash. Contoh: bcrypt.hashSync(password, 10)
            role: 'seeker',
            fullName: fullName,
            // Data profil default lainnya
            phoneNumber: "",
            address: "",
            profileSummary: "",
            profilePicture: "/assets/images/default_profile_picture.png",
            experiences: [],
            educations: [],
            skills: [],
            documents: [],
            savedJobs: []
        };
        db.users.push(newUser);
    } else if (role === 'company') {
        // ID untuk company bisa dimulai dari angka yang berbeda agar tidak bentrok, misal 100+
        const newId = (db.companies.length > 0 ? Math.max(...db.companies.map(c => c.id)) : 100) + 1;
        const newCompany = {
            id: newId,
            email: email,
            password: password, // Sama, di dunia nyata ini harus di-hash
            role: 'company',
            name: fullName,
            // Data profil default lainnya
            industry: "Belum diatur",
            location: "Belum diatur",
            tagline: "",
            about: "",
            website: "",
            logo: "/assets/images/company_logo_sample1.png", // logo default
            banner: "/assets/images/company_banner_sample1.jpg" // banner default
        };
        db.companies.push(newCompany);
    } else {
        return res.status(400).json({ message: 'Role tidak valid.' });
    }

    // 4. Simpan perubahan ke db.json
    writeDb(db);

    // 5. Kirim respons sukses
    res.status(201).json({ message: 'Registrasi berhasil! Silakan login dengan akun baru Anda.' });
});



module.exports = router;