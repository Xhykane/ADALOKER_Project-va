const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, '..', 'db.json');

const readDb = () => JSON.parse(fs.readFileSync(dbPath));

// GET /api/jobs -> Cari Lowongan
router.get('/jobs', (req, res) => {
    const db = readDb();
    let jobs = db.jobs.map(job => {
        const company = db.companies.find(c => c.id === job.companyId);
        return { ...job, companyName: company.name, companyLogo: company.logo };
    });

    // Filtering
    const { q, company, jobType, salary } = req.query;
    if (q) {
        jobs = jobs.filter(job => job.title.toLowerCase().includes(q.toLowerCase()));
    }
    if (company) {
        jobs = jobs.filter(job => job.companyName === company);
    }
    if (jobType) {
        jobs = jobs.filter(job => job.type === jobType);
    }
    if (salary) {
        const [min, max] = salary.split('-').map(Number);
        jobs = jobs.filter(job => {
            const [jobMin, jobMax] = job.salaryRange.split('-').map(Number);
            if(jobMin === 0 && jobMax === 0) return false;
            return jobMin >= min && (max ? jobMax <= max : true);
        });
    }

    res.json(jobs);
});

// GET /api/jobs/:id -> Detail Lowongan
router.get('/jobs/:id', (req, res) => {
    const db = readDb();
    const job = db.jobs.find(j => j.id === parseInt(req.params.id));
    if (!job) return res.status(404).json({ message: 'Lowongan tidak ditemukan.' });
    
    const company = db.companies.find(c => c.id === job.companyId);
    res.json({ ...job, company });
});

// GET /api/companies -> Daftar Perusahaan
router.get('/companies', (req, res) => {
    const db = readDb();
    const companiesWithJobCount = db.companies.map(company => {
        const jobCount = db.jobs.filter(job => job.companyId === company.id).length;
        return { ...company, jobCount };
    });
    res.json(companiesWithJobCount);
});

// GET /api/companies/:id -> Detail Perusahaan
router.get('/companies/:id', (req, res) => {
    const db = readDb();
    const company = db.companies.find(c => c.id === parseInt(req.params.id));
    if (!company) return res.status(404).json({ message: 'Perusahaan tidak ditemukan.' });

    const activeJobs = db.jobs.filter(j => j.companyId === company.id).map(job => {
        return {...job, companyName: company.name, companyLogo: company.logo };
    });
    res.json({ ...company, activeJobs });
});

module.exports = router;