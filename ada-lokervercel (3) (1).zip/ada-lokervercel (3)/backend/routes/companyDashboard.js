const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const auth = require('../middleware/authMiddleware');

const dbPath = path.join(__dirname, '..', 'db.json');

const readDb = () => JSON.parse(fs.readFileSync(dbPath));
const writeDb = (data) => fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));

const isCompany = (req, res, next) => {
    if (req.user.role !== 'company') {
        return res.status(403).json({ message: 'Akses ditolak. Hanya untuk perusahaan.' });
    }
    next();
};

// Middleware untuk semua rute di file ini
router.use(auth, isCompany);

// GET /api/company/profile
router.get('/profile', (req, res) => {
    const db = readDb();
    const company = db.companies.find(c => c.id === req.user.id);
    if (!company) {
        return res.status(404).json({ message: 'Profil perusahaan tidak ditemukan.' });
    }
    const { password, ...companyProfile } = company;
    res.json(companyProfile);
});

// GET /api/company/dashboard/stats
router.get('/dashboard/stats', (req, res) => {
    const db = readDb();
    const companyJobsIds = db.jobs.filter(j => j.companyId === req.user.id).map(j => j.id);
    const totalJobs = companyJobsIds.length;
    const totalCandidates = db.applications.filter(a => companyJobsIds.includes(a.jobId)).length;
    res.json({
        statTotalJobs: totalJobs,
        statTotalCandidates: totalCandidates,
        statTotalViews: Math.floor(Math.random() * 1000)
    });
});

// GET /api/company/jobs
router.get('/jobs', (req, res) => {
    const db = readDb();
    const companyJobs = db.jobs.filter(j => j.companyId === req.user.id);
    const jobsWithCount = companyJobs.map(job => ({
        ...job,
        applicationCount: db.applications.filter(app => app.jobId === job.id).length
    })).sort((a, b) => new Date(b.postedDate) - new Date(a.postedDate)); // Urutkan dari terbaru
    res.json(jobsWithCount);
});

// POST /api/company/jobs
router.post('/jobs', (req, res) => {
    const { title, location, type, salaryDisplay, salaryRange, description } = req.body;
    if(!title || !location || !type || !salaryDisplay || !salaryRange || !description) {
        return res.status(400).json({ message: 'Semua field formulir wajib diisi.' });
    }
    const db = readDb();
    const newJob = {
        id: (db.jobs.length > 0 ? Math.max(...db.jobs.map(j => j.id)) : 0) + 1,
        companyId: req.user.id,
        postedDate: new Date().toISOString(),
        title, location, type, salaryDisplay, salaryRange, description
    };
    db.jobs.push(newJob);
    writeDb(db);
    res.status(201).json({ message: `Lowongan "${title}" berhasil dibuat!`, job: newJob });
});

// PUT /api/company/jobs/:id
router.put('/jobs/:id', (req, res) => {
    const db = readDb();
    const jobId = parseInt(req.params.id);
    const jobIndex = db.jobs.findIndex(j => j.id === jobId && j.companyId === req.user.id);
    if (jobIndex === -1) {
        return res.status(404).json({ message: 'Lowongan tidak ditemukan atau Anda tidak punya akses.' });
    }
    const updatedJob = { ...db.jobs[jobIndex], ...req.body };
    db.jobs[jobIndex] = updatedJob;
    writeDb(db);
    res.json({ message: `Lowongan "${updatedJob.title}" berhasil diperbarui!`, job: updatedJob });
});

// DELETE /api/company/jobs/:id
router.delete('/jobs/:id', (req, res) => {
    let db = readDb();
    const jobId = parseInt(req.params.id);
    const initialLength = db.jobs.length;
    db.jobs = db.jobs.filter(j => !(j.id === jobId && j.companyId === req.user.id));
    if (db.jobs.length === initialLength) {
         return res.status(404).json({ message: 'Lowongan tidak ditemukan atau Anda tidak punya akses.' });
    }
    db.applications = db.applications.filter(app => app.jobId !== jobId);
    writeDb(db);
    res.json({ message: 'Lowongan berhasil dihapus.' });
});

// GET /api/company/jobs/:jobId/applications
router.get('/jobs/:jobId/applications', (req, res) => {
    const db = readDb();
    const jobId = parseInt(req.params.jobId);
    if (isNaN(jobId)) {
        return res.status(400).json({ message: 'ID lowongan tidak valid.' });
    }
    const job = db.jobs.find(j => j.id === jobId && j.companyId === req.user.id);
    if (!job) {
        return res.status(403).json({ message: 'Anda tidak punya akses ke lowongan ini.' });
    }
    const applications = db.applications.filter(a => a.jobId === jobId);
    res.json(applications);
});

module.exports = router;