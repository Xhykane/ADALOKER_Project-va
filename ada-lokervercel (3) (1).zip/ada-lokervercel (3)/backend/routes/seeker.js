const express = require('express');
const router = express.Router();
const fs = require('fs'); // <--- Tambahkan ini
const path = require('path');
const multer = require('multer');
const auth = require('../middleware/authMiddleware');

const dbPath = path.join(__dirname, '..', 'db.json');
const uploadDir = path.join(__dirname, '..', 'uploads'); // <--- Definisikan path folder upload

// --- PENGECEKAN FOLDER UPLOAD ---
// Cek apakah folder uploads ada, jika tidak, buat folder tersebut
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
    console.log(`Folder 'uploads' berhasil dibuat di: ${uploadDir}`);
}
// ------------------------------------

// Helper DB
const readDb = () => JSON.parse(fs.readFileSync(dbPath));
const writeDb = (data) => fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));

// Konfigurasi Multer untuk upload file lamaran
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir); // <--- Gunakan variabel path yang sudah kita definisikan
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage });

// GET /api/seeker/profile -> Mendapatkan profil user yang login
router.get('/profile', auth, (req, res) => {
    const db = readDb();
    const user = db.users.find(u => u.id === req.user.id);
    if (!user) return res.status(404).json({ message: 'User tidak ditemukan.' });
    const { password, ...userProfile } = user;
    res.json(userProfile);
});

// PUT /api/seeker/profile -> Update profil user
router.put('/profile', auth, (req, res) => {
    const db = readDb();
    const userIndex = db.users.findIndex(u => u.id === req.user.id);
    if (userIndex === -1) return res.status(404).json({ message: 'User tidak ditemukan.' });
    
    db.users[userIndex] = { ...db.users[userIndex], ...req.body, email: db.users[userIndex].email, role: db.users[userIndex].role };
    writeDb(db);
    
    const { password, ...updatedProfile } = db.users[userIndex];
    res.json({ message: 'Profil berhasil diperbarui', user: updatedProfile });
});

// POST /api/seeker/apply -> Mengirim lamaran
router.post('/apply/:jobId', auth, upload.fields([{ name: 'resume', maxCount: 1 }, { name: 'coverLetter', maxCount: 1 }]), (req, res) => {
    try {
        const db = readDb();
        const newApplication = {
            id: db.applications.length > 0 ? Math.max(...db.applications.map(a => a.id)) + 1 : 1,
            jobId: parseInt(req.params.jobId),
            userId: req.user.id,
            fullName: req.body.fullName,
            email: req.body.email,
            phoneNumber: req.body.phoneNumber,
            // Cek apakah file diunggah sebelum mengakses path-nya
            resumePath: req.files['resume'] ? req.files['resume'][0].path.replace(/\\/g, "/") : null,
            coverLetterPath: req.files['coverLetter'] ? req.files['coverLetter'][0].path.replace(/\\/g, "/") : null,
            status: 'Terkirim',
            appliedDate: new Date().toISOString()
        };

        if(!newApplication.resumePath) {
            return res.status(400).json({ message: 'File CV/Resume wajib diunggah.' });
        }

        db.applications.push(newApplication);
        writeDb(db);
        res.status(201).json({ message: 'Lamaran berhasil dikirim!', application: newApplication });

    } catch (error) {
        console.error("Error saat apply:", error);
        res.status(500).json({ message: "Terjadi kesalahan di server." });
    }
});

module.exports = router;