document.addEventListener("DOMContentLoaded", () => {
    // --- Variabel Global & Selektor DOM ---
    const API_BASE_URL = 'http://localhost:3001/api/company';
    let companyDataCache = { profile: null, jobs: [] };

    // Selektor DOM Utama
    const hamburger = document.querySelector(".hamburger");
    const navMenu = document.querySelector(".nav-menu");
    const navLinks = navMenu.querySelectorAll(".nav-link");
    const navCompanyNameSpan = document.getElementById("navCompanyName");
    const navCompanyLogoImg = document.getElementById("navCompanyLogo");
    const welcomeCompanyNameSpan = document.getElementById("welcomeCompanyName");
    const tabLinksDashboard = document.querySelectorAll(".tab-link-dashboard");
    const tabContentsDashboard = document.querySelectorAll(".tab-content-dashboard");

    // Selektor DOM untuk "Lowongan Diposting"
    const postedJobsListContainer = document.getElementById("companyPostedJobsList");
    const postedJobsCountSpan = document.getElementById("postedJobsCount");

    // Selektor DOM untuk "Manajemen Kandidat"
    const selectJobForCandidates = document.getElementById("selectJobForCandidates");
    const candidateListContainer = document.getElementById("candidateListForJob");

    // Selektor DOM untuk "Pasang/Edit Lowongan"
    const postJobForm = document.getElementById("postJobForm");
    const postJobMessage = document.getElementById("postJobMessage");
    const editJobIdInput = document.getElementById("editJobId");
    const formJobEditorTitle = document.getElementById("formJobEditorTitle");
    const clearJobFormButton = document.getElementById("clearJobFormButton");
    
    // Selektor DOM untuk "Profil Perusahaan"
    const companyProfileForm = document.getElementById("companyProfileForm");

    // Selektor DOM untuk Modal
    const deleteJobModal = document.getElementById("deleteJobModal");
    const confirmDeleteJobButton = document.getElementById("confirmDeleteJobButton");
    let jobIdToDelete = null;

    // --- Autentikasi & Inisialisasi ---
    const token = localStorage.getItem('adalokerToken');
    const userFromLogin = JSON.parse(localStorage.getItem('adalokerUser'));

    if (!token || !userFromLogin || userFromLogin.role !== 'company') {
        alert("Akses ditolak. Silakan login sebagai perusahaan.");
        window.location.href = '/index.html';
        return;
    }

    const authHeaders = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` };

    async function initializeDashboard() {
        setupEventListeners();
        try {
            const [profileRes, statsRes, jobsRes] = await Promise.all([
                fetch(`${API_BASE_URL}/profile`, { headers: authHeaders }),
                fetch(`${API_BASE_URL}/dashboard/stats`, { headers: authHeaders }),
                fetch(`${API_BASE_URL}/jobs`, { headers: authHeaders })
            ]);

            if (!profileRes.ok || !statsRes.ok || !jobsRes.ok) {
                throw new Error('Gagal memuat data dashboard. Sesi Anda mungkin telah berakhir. Silakan login kembali.');
            }

            companyDataCache.profile = await profileRes.json();
            const stats = await statsRes.json();
            companyDataCache.jobs = await jobsRes.json();

            updateUIWithData(companyDataCache.profile, stats, companyDataCache.jobs);
            handlePageHash();
        } catch (error) {
            console.error('Error initializing dashboard:', error);
            alert(error.message);
            // Logout jika ada error fatal
            localStorage.clear();
            window.location.href = '/index.html';
        }
    }

    // --- Fungsi Setup UI & Event Listeners ---
    function setupEventListeners() {
        // Navigasi
        hamburger.addEventListener("click", () => {
            hamburger.classList.toggle("active");
            navMenu.classList.toggle("active");
        });
        tabLinksDashboard.forEach(link => link.addEventListener("click", () => activateTab(link.dataset.tab)));
        navLinks.forEach(link => link.addEventListener("click", (e) => {
            e.preventDefault();
            const targetHref = e.currentTarget.getAttribute('href').split('#')[1];
            if (targetHref) activateTab(targetHref);
        }));
        document.getElementById("navCompanyProfileButton").addEventListener("click", (e) => {
            e.preventDefault();
            activateTab("companyProfileContent");
        });
        document.getElementById("addNewJobButtonFromStat").addEventListener("click", () => {
             activateTab('postNewJobContent');
             resetJobForm();
        });

        // Forms
        postJobForm.addEventListener('submit', handlePostJobFormSubmit);
        clearJobFormButton.addEventListener("click", resetJobForm);
        selectJobForCandidates.addEventListener('change', (e) => renderCandidatesForJob(e.target.value));
        companyProfileForm.addEventListener('submit', handleProfileFormSubmit);

        // Modal & Logout
        confirmDeleteJobButton.addEventListener('click', confirmDeleteJob);
        document.querySelectorAll(".close-button-modal, .cancel-delete-modal").forEach(btn => btn.addEventListener("click", () => deleteJobModal.style.display = 'none'));
        document.getElementById("dashboardLogoutButton").addEventListener("click", (e) => {
            e.preventDefault();
            if (confirm("Apakah Anda yakin ingin keluar?")) {
                localStorage.clear();
                window.location.href = "/index.html";
            }
        });
    }
    
    // --- Fungsi Utama untuk Update UI ---
    function updateUIWithData(profile, stats, jobs) {
        // Header & Welcome
        navCompanyNameSpan.textContent = profile.name;
        navCompanyLogoImg.src = profile.logo || 'assets/images/company_logo_sample1.png';
        welcomeCompanyNameSpan.textContent = `Selamat Datang, ${profile.name}!`;
        // Stats
        document.getElementById("statTotalJobs").textContent = stats.statTotalJobs || 0;
        document.getElementById("statTotalCandidates").textContent = stats.statTotalCandidates || 0;
        document.getElementById("statTotalViews").textContent = stats.statTotalViews || 0;
        // Content
        renderPostedJobs(jobs);
        updateCandidateJobSelect(jobs);
        document.getElementById("currentYearDashboard").textContent = new Date().getFullYear();
    }
    
    // --- Navigasi Tab ---
    function activateTab(tabId) {
        tabContentsDashboard.forEach(c => c.classList.toggle("active", c.id === tabId));
        tabLinksDashboard.forEach(l => l.classList.toggle("active", l.dataset.tab === tabId));
        navLinks.forEach(nl => nl.classList.toggle('active', nl.getAttribute('href').endsWith(tabId)));
        
        if (window.location.hash !== `#${tabId}`) {
             window.history.pushState(null, '', `#${tabId}`);
        }
        if (tabId === 'companyProfileContent') loadCompanyProfileForm();
    }
    function handlePageHash() {
        const hash = window.location.hash.substring(1);
        activateTab(hash || "postedJobsContent");
    }

    // --- Render "Lowongan Diposting" ---
    function renderPostedJobs(jobs) {
        postedJobsListContainer.innerHTML = "";
        postedJobsCountSpan.textContent = jobs.length;
        if (jobs.length === 0) {
            postedJobsListContainer.innerHTML = '<p class="empty-state-dashboard">Anda belum memposting lowongan apapun.</p>';
            return;
        }
        jobs.forEach(job => {
            const jobItem = document.createElement("div");
            jobItem.className = "job-item-company";
            jobItem.dataset.jobId = job.id;
            jobItem.innerHTML = `
                <div class="job-item-info"><h4>${job.title}</h4><p><i class="fas fa-map-marker-alt"></i> ${job.location} | <i class="fas fa-users"></i> ${job.applicationCount || 0} Pelamar</p></div>
                <div class="job-item-actions">
                    <button class="btn-sm btn-view-candidates"><i class="fas fa-eye"></i> Lihat Pelamar</button>
                    <button class="btn-sm btn-edit-job"><i class="fas fa-edit"></i> Edit</button>
                    <button class="btn-sm btn-delete-job" data-job-title="${job.title}"><i class="fas fa-trash-alt"></i> Hapus</button>
                </div>`;
            postedJobsListContainer.appendChild(jobItem);
        });
        attachJobActionListeners();
    }
    function attachJobActionListeners() {
        postedJobsListContainer.querySelectorAll(".btn-edit-job").forEach(btn => btn.addEventListener("click", handleEditJob));
        postedJobsListContainer.querySelectorAll(".btn-delete-job").forEach(btn => btn.addEventListener("click", handleDeleteJobPrompt));
        postedJobsListContainer.querySelectorAll(".btn-view-candidates").forEach(btn => btn.addEventListener("click", handleViewCandidates));
    }
    
    // --- CRUD Lowongan ---
    async function handlePostJobFormSubmit(event) {
        event.preventDefault();
        const formData = new FormData(postJobForm);
        const jobData = Object.fromEntries(formData.entries());
        const jobId = editJobIdInput.value;
        const method = jobId ? 'PUT' : 'POST';
        const url = jobId ? `${API_BASE_URL}/jobs/${jobId}` : `${API_BASE_URL}/jobs`;

        try {
            const response = await fetch(url, { method, headers: authHeaders, body: JSON.stringify(jobData) });
            const result = await response.json();
            if (!response.ok) throw new Error(result.message);
            
            await refreshData();
            resetJobForm();
            activateTab('postedJobsContent');
            alert(result.message); // Ganti postJobMessage dengan alert agar lebih terlihat
        } catch (error) {
            alert(`Error: ${error.message}`);
        }
    }
    function handleEditJob(event) {
        const jobItem = event.target.closest('.job-item-company');
        const jobId = jobItem.dataset.jobId;
        const jobToEdit = companyDataCache.jobs.find(job => job.id == jobId);
        if (jobToEdit) {
            formJobEditorTitle.textContent = `Edit Lowongan: ${jobToEdit.title}`;
            editJobIdInput.value = jobToEdit.id;
            document.getElementById("jobTitle").value = jobToEdit.title;
            document.getElementById("jobLocation").value = jobToEdit.location;
            document.getElementById("jobTypeSelect").value = jobToEdit.type;
            document.getElementById("jobSalaryDisplay").value = jobToEdit.salaryDisplay;
            document.getElementById("jobSalaryRangeInternal").value = jobToEdit.salaryRange;
            document.getElementById("jobDescription").value = jobToEdit.description;
            clearJobFormButton.style.display = "inline-block";
            activateTab('postNewJobContent');
        }
    }
    function resetJobForm() {
        postJobForm.reset();
        editJobIdInput.value = "";
        formJobEditorTitle.textContent = "Pasang Lowongan Kerja Baru";
        clearJobFormButton.style.display = "none";
        postJobMessage.textContent = "";
    }
    function handleDeleteJobPrompt(event) {
        const jobItem = event.target.closest('.job-item-company');
        jobIdToDelete = jobItem.dataset.jobId;
        document.getElementById("jobNameToDelete").textContent = event.target.dataset.jobTitle;
        deleteJobModal.style.display = "block";
    }
    async function confirmDeleteJob() {
        if (!jobIdToDelete) return;
        try {
            const response = await fetch(`${API_BASE_URL}/jobs/${jobIdToDelete}`, { method: 'DELETE', headers: authHeaders });
            if (!response.ok) throw new Error('Gagal menghapus lowongan.');
            await refreshData();
        } catch(error) {
            alert(error.message);
        } finally {
            deleteJobModal.style.display = "none";
            jobIdToDelete = null;
        }
    }

    // --- Manajemen Kandidat ---
    function updateCandidateJobSelect(jobs) {
        selectJobForCandidates.innerHTML = '<option value="">-- Pilih Lowongan --</option>';
        jobs.forEach(job => {
            const option = document.createElement("option");
            option.value = job.id;
            option.textContent = `${job.title} (${job.applicationCount || 0} pelamar)`;
            selectJobForCandidates.appendChild(option);
        });
    }
    async function renderCandidatesForJob(jobId) {
        candidateListContainer.innerHTML = "";
        if (!jobId) {
            candidateListContainer.innerHTML = '<p class="empty-state-dashboard">Pilih lowongan untuk melihat daftar kandidat.</p>';
            return;
        }
        candidateListContainer.innerHTML = '<p>Memuat kandidat...</p>';
        try {
            const response = await fetch(`${API_BASE_URL}/jobs/${jobId}/applications`, { headers: authHeaders });
            if (!response.ok) throw new Error('Gagal memuat kandidat.');
            const applications = await response.json();
            if (applications.length === 0) {
                 candidateListContainer.innerHTML = '<p class="empty-state-dashboard">Belum ada kandidat untuk lowongan ini.</p>';
                 return;
            }
            applications.forEach(app => {
                const item = document.createElement('div');
                item.className = 'candidate-item';
                item.innerHTML = `
                    <div class="candidate-item-info"><strong>${app.fullName}</strong><span>Melamar pada: ${new Date(app.appliedDate).toLocaleDateString('id-ID')}</span></div>
                    <div class="candidate-item-actions"><a href="http://localhost:3001/${app.resumePath}" target="_blank" class="btn-sm btn-view-profile"><i class="fas fa-file-alt"></i> Lihat CV</a></div>`;
                candidateListContainer.appendChild(item);
            });
        } catch(error) {
            candidateListContainer.innerHTML = `<p class="error-message">${error.message}</p>`;
        }
    }
    function handleViewCandidates(event) {
        const jobId = event.target.closest('.job-item-company').dataset.jobId;
        activateTab('candidatesContent');
        selectJobForCandidates.value = jobId;
        renderCandidatesForJob(jobId);
    }

    // --- Profil Perusahaan ---
    function loadCompanyProfileForm() {
        if (!companyDataCache.profile) return;
        const p = companyDataCache.profile;
        document.getElementById('profileCompanyName').value = p.name;
        document.getElementById('profileCompanyIndustry').value = p.industry || '';
        document.getElementById('profileCompanyLocation').value = p.location || '';
        document.getElementById('profileCompanyTagline').value = p.tagline || '';
        document.getElementById('profileCompanyAbout').value = p.about || '';
        document.getElementById('profileCompanyWebsite').value = p.website || '';
    }
    async function handleProfileFormSubmit(event) {
        event.preventDefault();
        // Implementasi logika simpan profil (mirip dengan simpan lowongan)
        alert("Fitur simpan profil belum diimplementasikan di versi ini.");
    }
    
    // --- Helper untuk Refresh Data ---
    async function refreshData() {
        const [statsRes, jobsRes] = await Promise.all([
            fetch(`${API_BASE_URL}/dashboard/stats`, { headers: authHeaders }),
            fetch(`${API_BASE_URL}/jobs`, { headers: authHeaders })
        ]);
        const stats = await statsRes.json();
        companyDataCache.jobs = await jobsRes.json();
        updateUIWithData(companyDataCache.profile, stats, companyDataCache.jobs);
    }
    
    // --- Inisialisasi Halaman ---
    initializeDashboard();
});