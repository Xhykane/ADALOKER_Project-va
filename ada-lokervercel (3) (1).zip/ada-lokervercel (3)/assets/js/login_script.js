
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const emailError = document.getElementById('emailError');
    const passwordError = document.getElementById('passwordError');
    const generalError = document.getElementById('generalError');
    const loginJobseekerButton = document.getElementById('loginJobseeker');
    const loginCompanyButton = document.getElementById('loginCompany');

    const API_URL = 'http://localhost:3001/api/auth/login';

    function validateEmail(email) {
        if (!email) return "Email tidak boleh kosong.";
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) return "Format email tidak valid.";
        return "";
    }

    function validatePassword(password) {
        if (!password) return "Password tidak boleh kosong.";
        return "";
    }

    function clearErrors() {
        emailError.textContent = '';
        passwordError.textContent = '';
        generalError.textContent = '';
        emailInput.classList.remove('input-error');
        passwordInput.classList.remove('input-error');
    }

    function displayError(element, message) {
        if (element) element.textContent = message;
    }

    async function handleLogin(userType) {
        clearErrors();
        let isValid = true;
        const originalButtonText = userType === 'jobseeker' ? loginJobseekerButton.innerHTML : loginCompanyButton.innerHTML;
        const button = userType === 'jobseeker' ? loginJobseekerButton : loginCompanyButton;

        const email = emailInput.value.trim();
        const password = passwordInput.value;

        const emailValidationMessage = validateEmail(email);
        if (emailValidationMessage) {
            displayError(emailError, emailValidationMessage);
            emailInput.classList.add('input-error');
            isValid = false;
        }

        const passwordValidationMessage = validatePassword(password);
        if (passwordValidationMessage) {
            displayError(passwordError, passwordValidationMessage);
            passwordInput.classList.add('input-error');
            isValid = false;
        }

        if (!isValid) {
            displayError(generalError, "Mohon periksa kembali input Anda.");
            return;
        }

        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
        
        try {
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password, loginAs: userType })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Terjadi kesalahan saat login.');
            }
            
            // Simpan token dan data user ke localStorage
            localStorage.setItem('adalokerToken', data.token);
            localStorage.setItem('adalokerUser', JSON.stringify(data.user));

            // Redirect berdasarkan peran
            if (data.user.role === 'seeker') {
                window.location.href = '/cari_lowongan.html';
            } else if (data.user.role === 'company') {
                window.location.href = '/dashboard_company.html';
            }

        } catch (error) {
            displayError(generalError, error.message);
        } finally {
            button.disabled = false;
            button.innerHTML = originalButtonText;
        }
    }

    if (loginJobseekerButton) {
        loginJobseekerButton.addEventListener('click', () => handleLogin('seeker'));
    }

    if (loginCompanyButton) {
        loginCompanyButton.addEventListener('click', () => handleLogin('company'));
    }

    if (loginForm) {
        loginForm.addEventListener('submit', (event) => {
            event.preventDefault();
        });
    }

    const inputs = document.querySelectorAll('.input-group input');
    inputs.forEach(input => {
        input.addEventListener('focus', () => input.parentElement.classList.add('input-group-focused'));
        input.addEventListener('blur', () => input.parentElement.classList.remove('input-group-focused'));
    });
});