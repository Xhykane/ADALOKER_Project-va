document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.querySelector(".hamburger");
    const navMenu = document.querySelector(".nav-menu");
    const currentYearSpan = document.getElementById("currentYearForm");
    const logoutButton = document.getElementById('logoutButtonSeeker_form');

    const applicationForm = document.getElementById('applicationForm');
    const formJobTitle = document.getElementById('formJobTitle');
    const formCompanyName = document.getElementById('formCompanyName');
    const resumeInput = document.getElementById('resume');
    const resumeFileNameSpan = document.getElementById('fileName');
    const submitButton = document.getElementById('submitApplicationButton');
    const formSubmissionMessage = document.getElementById('formSubmissionMessage');
    const successModal = document.getElementById('successModal');
    const closeModalButton = document.querySelector('.modal .close-button-modal');
    const backToJobsButton = document.getElementById('backToJobsButton');
    const modalJobTitleSpan = document.getElementById('modalJobTitle');

    const API_BASE_URL = 'http://localhost:3001/api';

    // --- UI & Auth ---
    if (hamburger && navMenu) {
        hamburger.addEventListener("click", () => {
            hamburger.classList.toggle("active");
            navMenu.classList.toggle("active");
        });
    }
    if (currentYearSpan) currentYearSpan.textContent = new Date().getFullYear();

    const token = localStorage.getItem('adalokerToken');
    if (!token) {
        alert("Anda harus login untuk melamar.");
        window.location.href = '/index.html';
        return;
    }
    if (logoutButton) {
        logoutButton.addEventListener('click', function(event) {
            event.preventDefault();
            if (confirm("Apakah Anda yakin ingin keluar?")) {
                localStorage.removeItem('adalokerToken');
                localStorage.removeItem('adalokerUser');
                window.location.href = "/index.html";
            }
        });
    }

    // --- Logika Halaman ---
    function getJobIdFromUrl() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('job_id');
    }

    async function fetchJobInfo() {
        const jobId = getJobIdFromUrl();
        if (!jobId) {
            formJobTitle.textContent = 'Formulir Lamaran';
            formCompanyName.textContent = 'Posisi tidak ditemukan';
            return;
        }
        try {
            const response = await fetch(`${API_BASE_URL}/jobs/${jobId}`);
            if (!response.ok) throw new Error('Data pekerjaan tidak ditemukan');
            const job = await response.json();
            formJobTitle.textContent = `Formulir Lamaran untuk ${job.title}`;
            formCompanyName.textContent = `di ${job.company.name}`;
            modalJobTitleSpan.textContent = job.title;
        } catch (error) {
            formJobTitle.textContent = 'Formulir Lamaran';
            formCompanyName.textContent = error.message;
        }
    }

    function updateFileName(fileInput, fileNameSpan) {
        if (fileInput.files.length > 0) {
            fileNameSpan.textContent = fileInput.files[0].name;
        } else {
            fileNameSpan.textContent = "Pilih File";
        }
    }
    if (resumeInput) resumeInput.addEventListener('change', () => updateFileName(resumeInput, resumeFileNameSpan));

    async function handleFormSubmit(event) {
        event.preventDefault();
        submitButton.disabled = true;
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mengirim...';
        formSubmissionMessage.textContent = '';

        const jobId = getJobIdFromUrl();
        // Pastikan Anda mengirim semua field form, termasuk file opsional
        const formData = new FormData(applicationForm); 

        try {
            const response = await fetch(`${API_BASE_URL}/seeker/apply/${jobId}`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                body: formData
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || 'Gagal mengirim lamaran.');
            }

            if (successModal) successModal.style.display = "block";

        } catch (error) {
            formSubmissionMessage.textContent = error.message;
            formSubmissionMessage.className = 'submission-message error';
        } finally {
            submitButton.disabled = false;
            submitButton.innerHTML = '<i class="fas fa-paper-plane"></i> Kirim Lamaran';
        }
    }

    if (applicationForm) {
        applicationForm.addEventListener('submit', handleFormSubmit);
    }
    
    
    function redirectToJobsPage() {
        if (successModal) {
            successModal.style.display = "none";
        }
       
        setTimeout(() => {
            window.location.href = '/cari_lowongan.html';
        }, 100);
    }

    if (closeModalButton) {
        closeModalButton.onclick = redirectToJobsPage;
    }
    if (backToJobsButton) {
        backToJobsButton.onclick = redirectToJobsPage;
    }
    

    fetchJobInfo();
});