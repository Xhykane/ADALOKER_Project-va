

document.addEventListener("DOMContentLoaded", () => {
  const hamburger = document.querySelector(".hamburger");
  const navMenu = document.querySelector(".nav-menu");
  const currentYearSpan = document.getElementById("currentYearDetail");
  const logoutButton = document.getElementById("logoutButtonSeeker_detail");
  const navProfileIcon = document.getElementById("navProfileIconSeeker_detail");
  const jobDetailContent = document.getElementById("jobDetailContent");
  const sidebarCompanyInfo = document.getElementById("sidebarCompanyInfo");
  const relatedJobsList = document.getElementById("relatedJobsList");
  const applyNowButton = document.getElementById("applyNowButton");
  const saveJobButton = document.getElementById("saveJobButton");

  const API_BASE_URL = 'http://localhost:3001/api';

  // --- Setup UI Umum & Auth ---
  if (hamburger && navMenu) {
      hamburger.addEventListener("click", () => {
          hamburger.classList.toggle("active");
          navMenu.classList.toggle("active");
      });
  }
  if (currentYearSpan) currentYearSpan.textContent = new Date().getFullYear();

  const token = localStorage.getItem('adalokerToken');
  if (token) {
      document.querySelector('.nav-profile').style.display = 'flex';
      if (logoutButton) {
          logoutButton.addEventListener("click", (event) => {
              event.preventDefault();
              if (confirm("Apakah Anda yakin ingin keluar?")) {
                  localStorage.removeItem('adalokerToken');
                  localStorage.removeItem('adalokerUser');
                  window.location.href = "/index.html";
              }
          });
      }
  } else {
      document.querySelector('.nav-profile').style.display = 'none';
      applyNowButton.textContent = 'Login untuk Melamar';
      applyNowButton.addEventListener('click', () => window.location.href = '/index.html');
      saveJobButton.style.display = 'none';
  }

  // --- Logika Halaman ---
  function getJobIdFromUrl() {
      const urlParams = new URLSearchParams(window.location.search);
      return urlParams.get("id");
  }

  function renderJobDetail(job) {
      if (!job || !jobDetailContent) {
          jobDetailContent.innerHTML = '<p class="error-message">Lowongan tidak ditemukan.</p>';
          return;
      }
      const company = job.company;
      document.title = `${job.title} - ADAloker`;
      jobDetailContent.innerHTML = `
          <div class="job-header">
              <img src="${company.logo}" alt="${company.name} Logo" class="company-logo-detail">
              <div class="job-title-main">
                  <h1>${job.title}</h1>
                  <a href="/company_detail_page.html?id=${company.id}" class="company-name-detail-link">${company.name}</a>
                  <span class="location-detail"><i class="fas fa-map-marker-alt"></i> ${job.location}</span>
              </div>
          </div>
          <div class="job-meta-info">
              <span class="meta-item"><i class="fas fa-briefcase"></i> ${job.type}</span>
              <span class="meta-item"><i class="fas fa-money-bill-wave"></i> ${job.salaryDisplay}</span>
              <span class="meta-item"><i class="far fa-calendar-alt"></i> Diposting: ${new Date(job.postedDate).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
          </div>
          <div class="job-section job-description-full">
              <h3>Deskripsi Pekerjaan</h3>
              ${job.description}
          </div>
      `;
      if (sidebarCompanyInfo) {
          sidebarCompanyInfo.innerHTML = `
              <h4>Tentang ${company.name}</h4>
              <img src="${company.logo}" alt="${company.name} Logo" style="max-width: 60px; border-radius: 5px; margin-bottom: 10px; background-color: #fff; padding: 3px;">
              <p>${company.about ? company.about.substring(0, 150) + "..." : "Deskripsi singkat perusahaan..."}</p>
              <p><a href="/company_detail_page.html?id=${company.id}" class="company-website-link">Lihat Profil Perusahaan</a></p>
          `;
      }
  }

  async function fetchJobDetails() {
      const jobId = getJobIdFromUrl();
      if (!jobId) {
          jobDetailContent.innerHTML = '<p class="error-message">ID lowongan tidak valid.</p>';
          return;
      }

      try {
          const response = await fetch(`${API_BASE_URL}/jobs/${jobId}`);
          if (!response.ok) {
              throw new Error('Lowongan tidak ditemukan.');
          }
          const jobData = await response.json();
          renderJobDetail(jobData);
          // Fetch related jobs (optional, for simplicity we can skip this or fetch all jobs and filter)
      } catch (error) {
          jobDetailContent.innerHTML = `<p class="error-message">${error.message}</p>`;
      }
  }
  
  if (applyNowButton && token) {
      applyNowButton.addEventListener("click", () => {
          const jobId = getJobIdFromUrl();
          if (jobId) {
              window.location.href = `/formulir_lamaran.html?job_id=${jobId}`;
          } else {
              alert("Tidak bisa melamar, ID lowongan tidak ditemukan.");
          }
      });
  }
  
  // Initial Load
  fetchJobDetails();
});