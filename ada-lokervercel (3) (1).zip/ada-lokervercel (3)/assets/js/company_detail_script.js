
document.addEventListener("DOMContentLoaded", () => {
  const hamburger = document.querySelector(".hamburger");
  const navMenu = document.querySelector(".nav-menu");
  const currentYearSpan = document.getElementById("currentYearCompanyDetail");
  const logoutButton = document.getElementById("logoutButtonSeeker_compDetail");
  
  const companyHeaderSection = document.getElementById("companyHeaderSection");
  const aboutCompanyContent = document.getElementById("aboutCompany");
  const companyCultureContent = document.getElementById("companyCulture");
  const companyActiveJobsGrid = document.getElementById("companyActiveJobsGrid");
  const activeJobsCountSpan = document.getElementById("activeJobsCount");

  const API_BASE_URL = 'http://localhost:3001/api';

  // --- UI & Auth ---
  if (hamburger && navMenu) {
      hamburger.addEventListener("click", () => {
          hamburger.classList.toggle("active");
          navMenu.classList.toggle("active");
      });
  }
  if (currentYearSpan) currentYearSpan.textContent = new Date().getFullYear();

  const token = localStorage.getItem('adalokerToken');
  if (token) {
      document.querySelector('.nav-profile').style.display = 'flex';
      if (logoutButton) {
          logoutButton.addEventListener("click", (event) => {
              event.preventDefault();
              if (confirm("Apakah Anda yakin ingin keluar?")) {
                  localStorage.removeItem('adalokerToken');
                  localStorage.removeItem('adalokerUser');
                  window.location.href = "/index.html";
              }
          });
      }
  } else {
      document.querySelector('.nav-profile').style.display = 'none';
  }

  // --- Tab Navigation ---
  const tabLinks = document.querySelectorAll(".tab-link");
  const tabContents = document.querySelectorAll(".tab-content");
  tabLinks.forEach(link => {
      link.addEventListener("click", () => {
          const tabId = link.dataset.tab;
          tabLinks.forEach(l => l.classList.remove("active"));
          link.classList.add("active");
          tabContents.forEach(content => {
              content.classList.remove("active");
              if (content.id === tabId) {
                  content.classList.add("active");
              }
          });
      });
  });

  // --- Logika Halaman ---
  function getCompanyIdFromUrl() {
      const urlParams = new URLSearchParams(window.location.search);
      return urlParams.get("id");
  }

  function renderCompanyHeader(company) {
      if (!companyHeaderSection || !company) return;
      companyHeaderSection.style.backgroundImage = `url('${company.banner || "https://via.placeholder.com/1500x350.png?text=Banner"}')`;
      companyHeaderSection.innerHTML = `<div class="container company-header-content"><img src="${company.logo}" alt="${company.name} Logo" class="company-header-logo"><div class="company-header-info"><h1>${company.name}</h1>${company.tagline ? `<p class="company-tagline">${company.tagline}</p>` : ""}<div class="company-meta"><span><i class="fas fa-industry"></i> ${company.industry}</span><span><i class="fas fa-map-marker-alt"></i> ${company.location}</span></div></div></div>`;
  }

  function renderAboutCompany(company) {
      if (!aboutCompanyContent || !company) return;
      aboutCompanyContent.innerHTML = `<h3 class="company-section-title">Tentang ${company.name}</h3>${company.about || "<p>Info akan segera tersedia.</p>"}${company.website ? `<p><strong>Website:</strong> <a href="${company.website}" target="_blank" rel="noopener noreferrer">${company.website}</a></p>` : ""}`;
  }

  function renderCompanyCulture(company) {
      if (!companyCultureContent || !company) return;
      // Kita asumsikan 'culture' tidak ada di DB, jadi tampilkan pesan default
      companyCultureContent.innerHTML = `<h3 class="company-section-title">Budaya Kerja Kami</h3><p>Informasi budaya kerja akan segera tersedia. Kami adalah lingkungan yang dinamis dan kolaboratif.</p>`;
  }

  function createJobCardForCompanyPage(job) {
      const card = document.createElement("div");
      card.classList.add("job-card");
      card.innerHTML = `
          <div class="job-card-header">
              <div class="job-title-company">
                  <h4>${job.title}</h4>
              </div>
          </div>
          <div class="job-details-icons">
              <p><i class="fas fa-map-marker-alt"></i> ${job.location}</p>
              <p><i class="fas fa-briefcase"></i> ${job.type}</p>
              <p><i class="fas fa-money-bill-wave"></i> ${job.salaryDisplay}</p>
          </div>
          <p class="job-description-short">${job.description ? job.description.substring(0, 100) + '...' : ''}</p>
          <a href="/detail_lowongan.html?id=${job.id}" class="btn-view-details">Lihat Detail</a>
      `;
      return card;
  }

  function renderActiveJobs(company) {
      if (!companyActiveJobsGrid || !company || !company.activeJobs) return;
      companyActiveJobsGrid.innerHTML = "";
      activeJobsCountSpan.textContent = company.activeJobs.length;

      if (company.activeJobs.length > 0) {
          company.activeJobs.forEach(job => {
              const jobCard = createJobCardForCompanyPage(job);
              companyActiveJobsGrid.appendChild(jobCard);
          });
      } else {
          companyActiveJobsGrid.innerHTML = '<p class="loading-tab-content">Tidak ada lowongan aktif saat ini.</p>';
      }
  }
  
  async function fetchCompanyDetails() {
      const companyId = getCompanyIdFromUrl();
      const wrapper = document.getElementById("companyDetailWrapper");
      if (!companyId) {
          if(wrapper) wrapper.innerHTML = '<div class="container" style="padding:50px 0; text-align:center;">ID perusahaan tidak valid.</div>';
          return;
      }

      try {
          const response = await fetch(`${API_BASE_URL}/companies/${companyId}`);
          if (!response.ok) throw new Error('Profil perusahaan tidak ditemukan.');
          
          const companyData = await response.json();
          
          document.title = `${companyData.name} - Profil Perusahaan - ADAloker`;
          renderCompanyHeader(companyData);
          renderAboutCompany(companyData);
          renderCompanyCulture(companyData);
          renderActiveJobs(companyData);

      } catch(error) {
          if(wrapper) wrapper.innerHTML = `<div class="container" style="padding:50px 0; text-align:center;">${error.message}</div>`;
      }
  }

  fetchCompanyDetails();
});