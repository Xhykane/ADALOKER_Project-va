
document.addEventListener("DOMContentLoaded", () => {
  const hamburger = document.querySelector(".hamburger");
  const navMenu = document.querySelector(".nav-menu");
  const currentYearSpan = document.getElementById("currentYearCompanies");
  const logoutButton = document.getElementById("logoutButtonSeeker_companies");
  const companyListingsGrid = document.getElementById("companyListingsGrid");
  const companySearchInput = document.getElementById("companySearchInput");
  const companySearchButton = document.getElementById("companySearchButton");
  const companySortBy = document.getElementById("companySortBy");
  const displayedCompanyCountSpan = document.getElementById("displayedCompanyCount");
  const noCompaniesMessage = document.getElementById("noCompaniesMessage");
  
  const API_BASE_URL = 'http://localhost:3001/api';
  let allCompaniesData = []; // Untuk menyimpan data dari API

  // --- UI & Auth ---
  if (hamburger && navMenu) {
      hamburger.addEventListener("click", () => {
          hamburger.classList.toggle("active");
          navMenu.classList.toggle("active");
      });
  }
  if (currentYearSpan) currentYearSpan.textContent = new Date().getFullYear();

  const token = localStorage.getItem('adalokerToken');
  if (token) {
      document.querySelector('.nav-profile').style.display = 'flex';
      if (logoutButton) {
          logoutButton.addEventListener("click", (event) => {
              event.preventDefault();
              if (confirm("Apakah Anda yakin ingin keluar?")) {
                  localStorage.removeItem('adalokerToken');
                  localStorage.removeItem('adalokerUser');
                  window.location.href = "/index.html";
              }
          });
      }
  } else {
      document.querySelector('.nav-profile').style.display = 'none';
  }

  // --- Logika Halaman ---
  function createCompanyCard(company) {
      const card = document.createElement("div");
      card.classList.add("company-card");
      card.innerHTML = `
          <div class="company-banner"><img src="${company.banner || "https://via.placeholder.com/300x120.png?text=Banner"}" alt="${company.name} Banner"></div>
          <div class="company-card-content">
              <div class="company-logo-name"><img src="${company.logo || "https://via.placeholder.com/50x50.png?text=Logo"}" alt="${company.name} Logo" class="company-logo"><h3>${company.name}</h3></div>
              <div class="company-info"><p><i class="fas fa-industry"></i> ${company.industry}</p><p><i class="fas fa-map-marker-alt"></i> ${company.location}</p></div>
              <p class="company-description-short">${company.about ? company.about.substring(0, 80) + '...' : ''}</p>
              <a href="/company_detail_page.html?id=${company.id}" class="company-jobs-link">Lihat Profil & ${company.jobCount} Lowongan</a>
          </div>
      `;
      card.addEventListener("click", (event) => {
          if (!event.target.classList.contains("company-jobs-link")) {
              window.location.href = `/company_detail_page.html?id=${company.id}`;
          }
      });
      return card;
  }

  function renderCompanyListings(companiesToRender) {
      companyListingsGrid.innerHTML = "";
      if (companiesToRender.length === 0) {
          noCompaniesMessage.style.display = "block";
      } else {
          noCompaniesMessage.style.display = "none";
          companiesToRender.forEach(company => {
              const companyCard = createCompanyCard(company);
              companyListingsGrid.appendChild(companyCard);
          });
      }
      displayedCompanyCountSpan.textContent = companiesToRender.length;
  }

  function sortCompanies(companies, sortBy) {
      const sortedCompanies = [...companies];
      switch (sortBy) {
          case "name-asc":
              sortedCompanies.sort((a, b) => a.name.localeCompare(b.name));
              break;
          case "name-desc":
              sortedCompanies.sort((a, b) => b.name.localeCompare(a.name));
              break;
          case "jobs-desc":
              sortedCompanies.sort((a, b) => b.jobCount - a.jobCount);
              break;
          default:
              sortedCompanies.sort((a, b) => a.name.localeCompare(b.name));
      }
      return sortedCompanies;
  }

  function filterAndSortCompanies() {
      const searchTerm = companySearchInput.value.toLowerCase().trim();
      const sortByValue = companySortBy.value;

      const filteredCompanies = allCompaniesData.filter(company => {
          return (
              searchTerm === "" ||
              company.name.toLowerCase().includes(searchTerm) ||
              company.industry.toLowerCase().includes(searchTerm) ||
              company.location.toLowerCase().includes(searchTerm)
          );
      });

      const sortedAndFilteredCompanies = sortCompanies(filteredCompanies, sortByValue);
      renderCompanyListings(sortedAndFilteredCompanies);
  }

  async function fetchInitialData() {
      companyListingsGrid.innerHTML = '<p>Memuat daftar perusahaan...</p>';
      try {
          const response = await fetch(`${API_BASE_URL}/companies`);
          if (!response.ok) throw new Error('Gagal memuat data perusahaan.');
          
          allCompaniesData = await response.json();
          filterAndSortCompanies(); // Render data setelah berhasil di-fetch
      } catch (error) {
          companyListingsGrid.innerHTML = `<p class="error-message">${error.message}</p>`;
      }
  }

  // Event Listeners
  if (companySearchButton) companySearchButton.addEventListener("click", filterAndSortCompanies);
  if (companySearchInput) companySearchInput.addEventListener("keyup", (event) => {
      if (event.key === "Enter" || companySearchInput.value.trim() === "") {
          filterAndSortCompanies();
      }
  });
  if (companySortBy) companySortBy.addEventListener("change", filterAndSortCompanies);
  
  // Initial Load
  fetchInitialData();
});