document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('registerForm');
    const fullNameInput = document.getElementById('fullName');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const roleSelect = document.getElementById('role');
    const registerButton = document.getElementById('registerButton');
    
    const fullNameError = document.getElementById('fullNameError');
    const emailError = document.getElementById('emailError');
    const passwordError = document.getElementById('passwordError');
    const confirmPasswordError = document.getElementById('confirmPasswordError');
    const generalError = document.getElementById('generalError');

    const API_URL = 'http://localhost:3001/api/auth/register';

    function clearErrors() {
        fullNameError.textContent = '';
        emailError.textContent = '';
        passwordError.textContent = '';
        confirmPasswordError.textContent = '';
        generalError.textContent = '';
    }
    
    async function handleRegister(event) {
        event.preventDefault();
        clearErrors();
        let isValid = true;
        
        // --- Validasi Client-side ---
        if (fullNameInput.value.trim() === '') {
            fullNameError.textContent = 'Nama tidak boleh kosong.';
            isValid = false;
        }
        if (emailInput.value.trim() === '') {
            emailError.textContent = 'Email tidak boleh kosong.';
            isValid = false;
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailInput.value.trim())) {
             emailError.textContent = 'Format email tidak valid.';
             isValid = false;
        }
        if (passwordInput.value.length < 6) {
            passwordError.textContent = 'Password minimal harus 6 karakter.';
            isValid = false;
        }
        if (passwordInput.value !== confirmPasswordInput.value) {
            confirmPasswordError.textContent = 'Konfirmasi password tidak cocok.';
            isValid = false;
        }
        
        if (!isValid) {
            generalError.textContent = 'Mohon periksa kembali input Anda.';
            return;
        }
        
        // --- Kirim data ke Backend ---
        registerButton.disabled = true;
        registerButton.textContent = 'Mendaftar...';
        
        const payload = {
            fullName: fullNameInput.value.trim(),
            email: emailInput.value.trim(),
            password: passwordInput.value,
            role: roleSelect.value
        };
        
        try {
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.message || 'Terjadi kesalahan saat registrasi.');
            }
            
            // Registrasi berhasil
            alert(data.message);
            window.location.href = '/index.html'; // Arahkan ke halaman login
            
        } catch (error) {
            generalError.textContent = error.message;
        } finally {
            registerButton.disabled = false;
            registerButton.textContent = 'Daftar Sekarang';
        }
    }

    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
});