

document.addEventListener("DOMContentLoaded", () => {
  const hamburger = document.querySelector(".hamburger");
  const navMenu = document.querySelector(".nav-menu");
  const currentYearSpan = document.getElementById("currentYear");
  const jobListingsGrid = document.getElementById("jobListingsGrid");
  const searchInput = document.getElementById("searchInput");
  const searchButton = document.getElementById("searchButton");
  const filterCompany = document.getElementById("filterCompany");
  const filterJobType = document.getElementById("filterJobType");
  const filterSalary = document.getElementById("filterSalary");
  const resetFilterButton = document.getElementById("resetFilterButton");
  const displayedJobCountSpan = document.getElementById("displayedJobCount");
  const noJobsMessage = document.getElementById("noJobsMessage");
  const logoutButtonSeeker = document.getElementById("logoutButtonSeeker");
  const navProfileIconSeeker = document.getElementById("navProfileIconSeeker");

  const API_BASE_URL = 'http://localhost:3001/api';

  // --- Setup UI Umum ---
  if (hamburger && navMenu) {
      hamburger.addEventListener("click", () => {
          hamburger.classList.toggle("active");
          navMenu.classList.toggle("active");
      });
      document.querySelectorAll(".nav-link, .profile-button, .logout-button-nav").forEach(n =>
          n.addEventListener("click", () => {
              if (window.innerWidth < 769) {
                  hamburger.classList.remove("active");
                  navMenu.classList.remove("active");
              }
          })
      );
  }

  if (currentYearSpan) {
      currentYearSpan.textContent = new Date().getFullYear();
  }
  
  // --- Autentikasi & Navigasi ---
  const token = localStorage.getItem('adalokerToken');
  const user = JSON.parse(localStorage.getItem('adalokerUser'));

  if (token && user && user.role === 'seeker') {
      // Jika login, tampilkan tombol profil & logout
      document.querySelector('.nav-profile').style.display = 'flex';
      // Ambil data profil untuk gambar, jika perlu
      // fetchSeekerProfile(); 
  } else {
      // Jika tidak login atau bukan seeker, bisa redirect atau sembunyikan tombol
      // Untuk demo, kita asumsikan bisa lihat lowongan tanpa login
      document.querySelector('.nav-profile').style.display = 'none';
  }

  if (logoutButtonSeeker) {
      logoutButtonSeeker.addEventListener("click", (event) => {
          event.preventDefault();
          if (confirm("Apakah Anda yakin ingin keluar?")) {
              localStorage.removeItem('adalokerToken');
              localStorage.removeItem('adalokerUser');
              window.location.href = "/index.html";
          }
      });
  }

  // --- Logika Halaman ---
  function createJobCard(job) {
      const card = document.createElement("div");
      card.classList.add("job-card");
      card.innerHTML = `
          <div class="job-card-header">
              <img src="${job.companyLogo || '/ADAloker_vercel/assets/images/company_logo_sample1.png'}" alt="${job.companyName} Logo" class="company-logo">
              <div class="job-title-company">
                  <h4>${job.title}</h4>
                  <p class="company-name">${job.companyName}</p>
              </div>
          </div>
          <div class="job-details-icons">
              <p><i class="fas fa-map-marker-alt"></i> ${job.location}</p>
              <p><i class="fas fa-briefcase"></i> ${job.type}</p>
              <p><i class="fas fa-money-bill-wave"></i> ${job.salaryDisplay}</p>
          </div>
          <p class="job-description-short">${job.description.substring(0, 100)}...</p>
          <a href="/detail_lowongan.html?id=${job.id}" class="btn-view-details">Lihat Detail</a>
      `;
      card.addEventListener('click', (event) => {
          if (!event.target.classList.contains('btn-view-details')) {
              window.location.href = `/detail_lowongan.html?id=${job.id}`;
          }
      });
      return card;
  }

  function renderJobListings(jobsToRender) {
      jobListingsGrid.innerHTML = "";
      if (jobsToRender.length === 0) {
          noJobsMessage.style.display = "block";
      } else {
          noJobsMessage.style.display = "none";
          jobsToRender.forEach(job => {
              const jobCard = createJobCard(job);
              jobListingsGrid.appendChild(jobCard);
          });
      }
      displayedJobCountSpan.textContent = jobsToRender.length;
  }

  async function fetchAndRenderJobs() {
      jobListingsGrid.innerHTML = '<p>Memuat lowongan...</p>';
      const params = new URLSearchParams();
      
      const searchTerm = searchInput.value.toLowerCase().trim();
      if (searchTerm) params.append('q', searchTerm);

      const selectedCompany = filterCompany.value;
      if (selectedCompany) params.append('company', selectedCompany);

      const selectedJobType = filterJobType.value;
      if (selectedJobType) params.append('jobType', selectedJobType);

      const selectedSalaryRange = filterSalary.value;
      if (selectedSalaryRange) params.append('salary', selectedSalaryRange);

      try {
          const response = await fetch(`${API_BASE_URL}/jobs?${params.toString()}`);
          if (!response.ok) {
              throw new Error('Gagal mengambil data lowongan.');
          }
          const jobs = await response.json();
          renderJobListings(jobs);
      } catch (error) {
          jobListingsGrid.innerHTML = `<p class="error-message">${error.message}</p>`;
          noJobsMessage.style.display = 'block';
          noJobsMessage.textContent = 'Tidak bisa memuat lowongan. Coba lagi nanti.';
      }
  }

  function resetFilters() {
      searchInput.value = "";
      filterCompany.value = "";
      filterJobType.value = "";
      filterSalary.value = "";
      fetchAndRenderJobs();
  }

  // Event Listeners
  if (searchButton) searchButton.addEventListener("click", fetchAndRenderJobs);
  if (searchInput) searchInput.addEventListener("keyup", (event) => {
      if (event.key === "Enter") {
          fetchAndRenderJobs();
      }
  });
  if (filterCompany) filterCompany.addEventListener("change", fetchAndRenderJobs);
  if (filterJobType) filterJobType.addEventListener("change", fetchAndRenderJobs);
  if (filterSalary) filterSalary.addEventListener("change", fetchAndRenderJobs);
  if (resetFilterButton) resetFilterButton.addEventListener("click", resetFilters);

  // Initial load
  fetchAndRenderJobs();
});