const express = require("express")
const { body, validationResult, query } = require("express-validator")
const database = require("../config/database")
const { authenticateToken, authorizeCompany } = require("../middleware/auth")

const router = express.Router()
const db = database.getDb()

// Get all jobs with filtering and pagination
router.get(
  "/",
  [
    query("page").optional().isInt({ min: 1 }),
    query("limit").optional().isInt({ min: 1, max: 100 }),
    query("search").optional().trim(),
    query("company").optional().trim(),
    query("job_type").optional().isIn(["WFO", "WFH", "Hybrid", "WFA"]),
    query("salary_min").optional().isInt({ min: 0 }),
    query("salary_max").optional().isInt({ min: 0 }),
  ],
  (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
    }

    const page = Number.parseInt(req.query.page) || 1
    const limit = Number.parseInt(req.query.limit) || 10
    const offset = (page - 1) * limit

    const whereConditions = ['j.status = "active"']
    const params = []

    // Build WHERE conditions based on filters
    if (req.query.search) {
      whereConditions.push("(j.title LIKE ? OR j.description LIKE ? OR c.name LIKE ?)")
      const searchTerm = `%${req.query.search}%`
      params.push(searchTerm, searchTerm, searchTerm)
    }

    if (req.query.company) {
      whereConditions.push("c.name LIKE ?")
      params.push(`%${req.query.company}%`)
    }

    if (req.query.job_type) {
      whereConditions.push("j.job_type = ?")
      params.push(req.query.job_type)
    }

    if (req.query.salary_min) {
      whereConditions.push("j.salary_min >= ?")
      params.push(req.query.salary_min)
    }

    if (req.query.salary_max) {
      whereConditions.push("j.salary_max <= ?")
      params.push(req.query.salary_max)
    }

    const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(" AND ")}` : ""

    // Get total count
    const countQuery = `
    SELECT COUNT(*) as total
    FROM jobs j
    JOIN companies c ON j.company_id = c.id
    ${whereClause}
  `

    db.get(countQuery, params, (err, countResult) => {
      if (err) {
        return res.status(500).json({ error: "Database error" })
      }

      const total = countResult.total

      // Get jobs with pagination
      const jobsQuery = `
      SELECT 
        j.*,
        c.name as company_name,
        c.logo as company_logo,
        c.location as company_location,
        (SELECT COUNT(*) FROM job_applications WHERE job_id = j.id) as applicants_count
      FROM jobs j
      JOIN companies c ON j.company_id = c.id
      ${whereClause}
      ORDER BY j.created_at DESC
      LIMIT ? OFFSET ?
    `

      db.all(jobsQuery, [...params, limit, offset], (err, jobs) => {
        if (err) {
          return res.status(500).json({ error: "Database error" })
        }

        res.json({
          jobs,
          pagination: {
            page,
            limit,
            total,
            totalPages: Math.ceil(total / limit),
          },
        })
      })
    })
  },
)

// Get job by ID
router.get("/:id", (req, res) => {
  const jobId = req.params.id

  // Increment view count
  db.run("UPDATE jobs SET views_count = views_count + 1 WHERE id = ?", [jobId])

  const query = `
    SELECT 
      j.*,
      c.name as company_name,
      c.logo as company_logo,
      c.about as company_description,
      c.website as company_website,
      c.location as company_location,
      (SELECT COUNT(*) FROM job_applications WHERE job_id = j.id) as applicants_count
    FROM jobs j
    JOIN companies c ON j.company_id = c.id
    WHERE j.id = ? AND j.status = 'active'
  `

  db.get(query, [jobId], (err, job) => {
    if (err) {
      return res.status(500).json({ error: "Database error" })
    }

    if (!job) {
      return res.status(404).json({ error: "Job not found" })
    }

    res.json(job)
  })
})

// Create new job (Company only)
router.post(
  "/",
  authenticateToken,
  authorizeCompany,
  [
    body("title").notEmpty().trim(),
    body("location").notEmpty().trim(),
    body("job_type").isIn(["WFO", "WFH", "Hybrid", "WFA"]),
    body("salary_display").notEmpty().trim(),
    body("salary_min").optional().isInt({ min: 0 }),
    body("salary_max").optional().isInt({ min: 0 }),
    body("description").notEmpty().trim(),
  ],
  (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
    }

    // Get company ID for the authenticated user
    db.get("SELECT id FROM companies WHERE user_id = ?", [req.user.id], (err, company) => {
      if (err) {
        return res.status(500).json({ error: "Database error" })
      }

      if (!company) {
        return res.status(404).json({ error: "Company profile not found" })
      }

      const { title, location, job_type, salary_display, salary_min, salary_max, description, requirements, benefits } =
        req.body

      db.run(
        `INSERT INTO jobs (
        company_id, title, location, job_type, salary_display, 
        salary_min, salary_max, description, requirements, benefits
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          company.id,
          title,
          location,
          job_type,
          salary_display,
          salary_min,
          salary_max,
          description,
          requirements,
          benefits,
        ],
        function (err) {
          if (err) {
            return res.status(500).json({ error: "Failed to create job" })
          }

          res.status(201).json({
            message: "Job created successfully",
            job_id: this.lastID,
          })
        },
      )
    })
  },
)

// Update job (Company only)
router.put(
  "/:id",
  authenticateToken,
  authorizeCompany,
  [
    body("title").optional().notEmpty().trim(),
    body("location").optional().notEmpty().trim(),
    body("job_type").optional().isIn(["WFO", "WFH", "Hybrid", "WFA"]),
    body("salary_display").optional().notEmpty().trim(),
    body("description").optional().notEmpty().trim(),
  ],
  (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
    }

    const jobId = req.params.id

    // Check if job belongs to the company
    db.get(
      "SELECT j.id FROM jobs j JOIN companies c ON j.company_id = c.id WHERE j.id = ? AND c.user_id = ?",
      [jobId, req.user.id],
      (err, job) => {
        if (err) {
          return res.status(500).json({ error: "Database error" })
        }

        if (!job) {
          return res.status(404).json({ error: "Job not found or access denied" })
        }

        const updateFields = []
        const updateValues = []

        // Build dynamic update query
        Object.keys(req.body).forEach((key) => {
          if (req.body[key] !== undefined) {
            updateFields.push(`${key} = ?`)
            updateValues.push(req.body[key])
          }
        })

        if (updateFields.length === 0) {
          return res.status(400).json({ error: "No fields to update" })
        }

        updateFields.push("updated_at = CURRENT_TIMESTAMP")
        updateValues.push(jobId)

        const updateQuery = `UPDATE jobs SET ${updateFields.join(", ")} WHERE id = ?`

        db.run(updateQuery, updateValues, (err) => {
          if (err) {
            return res.status(500).json({ error: "Failed to update job" })
          }

          res.json({ message: "Job updated successfully" })
        })
      },
    )
  },
)

// Delete job (Company only)
router.delete("/:id", authenticateToken, authorizeCompany, (req, res) => {
  const jobId = req.params.id

  // Check if job belongs to the company
  db.get(
    "SELECT j.id FROM jobs j JOIN companies c ON j.company_id = c.id WHERE j.id = ? AND c.user_id = ?",
    [jobId, req.user.id],
    (err, job) => {
      if (err) {
        return res.status(500).json({ error: "Database error" })
      }

      if (!job) {
        return res.status(404).json({ error: "Job not found or access denied" })
      }

      db.run("DELETE FROM jobs WHERE id = ?", [jobId], (err) => {
        if (err) {
          return res.status(500).json({ error: "Failed to delete job" })
        }

        res.json({ message: "Job deleted successfully" })
      })
    },
  )
})

// Get jobs by company (Company only)
router.get("/company/my-jobs", authenticateToken, authorizeCompany, (req, res) => {
  const query = `
    SELECT 
      j.*,
      (SELECT COUNT(*) FROM job_applications WHERE job_id = j.id) as applicants_count
    FROM jobs j
    JOIN companies c ON j.company_id = c.id
    WHERE c.user_id = ?
    ORDER BY j.created_at DESC
  `

  db.all(query, [req.user.id], (err, jobs) => {
    if (err) {
      return res.status(500).json({ error: "Database error" })
    }

    res.json(jobs)
  })
})

module.exports = router
