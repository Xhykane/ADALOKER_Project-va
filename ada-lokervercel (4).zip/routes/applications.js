const express = require("express")
const { body, validationResult } = require("express-validator")
const database = require("../config/database")
const { authenticateToken, authorizeJobseeker, authorizeCompany } = require("../middleware/auth")

const router = express.Router()
const db = database.getDb()

// Apply for a job (Jobseeker only)
router.post(
  "/",
  authenticateToken,
  authorizeJobseeker,
  [
    body("job_id").isInt({ min: 1 }),
    body("full_name").notEmpty().trim(),
    body("email").isEmail().normalizeEmail(),
    body("phone_number").notEmpty().trim(),
    body("address").optional().trim(),
    body("portfolio_link").optional().isURL(),
    body("additional_info").optional().trim(),
    body("expected_salary").optional().isInt({ min: 0 }),
  ],
  (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
    }

    const { job_id, full_name, email, phone_number, address, portfolio_link, additional_info, expected_salary } =
      req.body

    // Check if job exists and is active
    db.get('SELECT id FROM jobs WHERE id = ? AND status = "active"', [job_id], (err, job) => {
      if (err) {
        return res.status(500).json({ error: "Database error" })
      }

      if (!job) {
        return res.status(404).json({ error: "Job not found or no longer active" })
      }

      // Check if user already applied
      db.get(
        "SELECT id FROM job_applications WHERE job_id = ? AND user_id = ?",
        [job_id, req.user.id],
        (err, existingApplication) => {
          if (err) {
            return res.status(500).json({ error: "Database error" })
          }

          if (existingApplication) {
            return res.status(400).json({ error: "You have already applied for this job" })
          }

          // Create application
          db.run(
            `INSERT INTO job_applications (
          job_id, user_id, full_name, email, phone_number, 
          address, portfolio_link, additional_info, expected_salary
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              job_id,
              req.user.id,
              full_name,
              email,
              phone_number,
              address,
              portfolio_link,
              additional_info,
              expected_salary,
            ],
            function (err) {
              if (err) {
                return res.status(500).json({ error: "Failed to submit application" })
              }

              res.status(201).json({
                message: "Application submitted successfully",
                application_id: this.lastID,
              })
            },
          )
        },
      )
    })
  },
)

// Get applications for a job (Company only)
router.get("/job/:jobId", authenticateToken, authorizeCompany, (req, res) => {
  const jobId = req.params.jobId

  // Verify job belongs to the company
  db.get(
    "SELECT j.id FROM jobs j JOIN companies c ON j.company_id = c.id WHERE j.id = ? AND c.user_id = ?",
    [jobId, req.user.id],
    (err, job) => {
      if (err) {
        return res.status(500).json({ error: "Database error" })
      }

      if (!job) {
        return res.status(404).json({ error: "Job not found or access denied" })
      }

      // Get applications
      const query = `
        SELECT 
          ja.*,
          u.profile_picture
        FROM job_applications ja
        JOIN users u ON ja.user_id = u.id
        WHERE ja.job_id = ?
        ORDER BY ja.applied_at DESC
      `

      db.all(query, [jobId], (err, applications) => {
        if (err) {
          return res.status(500).json({ error: "Database error" })
        }

        res.json(applications)
      })
    },
  )
})

// Get user's applications (Jobseeker only)
router.get("/my-applications", authenticateToken, authorizeJobseeker, (req, res) => {
  const query = `
    SELECT 
      ja.*,
      j.title as job_title,
      j.location as job_location,
      j.salary_display,
      c.name as company_name,
      c.logo as company_logo
    FROM job_applications ja
    JOIN jobs j ON ja.job_id = j.id
    JOIN companies c ON j.company_id = c.id
    WHERE ja.user_id = ?
    ORDER BY ja.applied_at DESC
  `

  db.all(query, [req.user.id], (err, applications) => {
    if (err) {
      return res.status(500).json({ error: "Database error" })
    }

    res.json(applications)
  })
})

// Update application status (Company only)
router.put(
  "/:id/status",
  authenticateToken,
  authorizeCompany,
  [body("status").isIn(["pending", "reviewed", "shortlisted", "rejected", "hired"])],
  (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
    }

    const applicationId = req.params.id
    const { status } = req.body

    // Verify application belongs to company's job
    const query = `
    SELECT ja.id 
    FROM job_applications ja
    JOIN jobs j ON ja.job_id = j.id
    JOIN companies c ON j.company_id = c.id
    WHERE ja.id = ? AND c.user_id = ?
  `

    db.get(query, [applicationId, req.user.id], (err, application) => {
      if (err) {
        return res.status(500).json({ error: "Database error" })
      }

      if (!application) {
        return res.status(404).json({ error: "Application not found or access denied" })
      }

      db.run("UPDATE job_applications SET status = ? WHERE id = ?", [status, applicationId], (err) => {
        if (err) {
          return res.status(500).json({ error: "Failed to update application status" })
        }

        res.json({ message: "Application status updated successfully" })
      })
    })
  },
)

module.exports = router
