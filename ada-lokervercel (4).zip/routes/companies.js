const express = require("express")
const { body, validationResult } = require("express-validator")
const database = require("../config/database")
const { authenticateToken, authorizeCompany } = require("../middleware/auth")

const router = express.Router()
const db = database.getDb()

// Get all companies
router.get("/", (req, res) => {
  const query = `
    SELECT 
      c.*,
      (SELECT COUNT(*) FROM jobs WHERE company_id = c.id AND status = 'active') as active_jobs_count
    FROM companies c
    ORDER BY c.name ASC
  `

  db.all(query, [], (err, companies) => {
    if (err) {
      return res.status(500).json({ error: "Database error" })
    }

    res.json(companies)
  })
})

// Get company by ID
router.get("/:id", (req, res) => {
  const companyId = req.params.id

  const query = `
    SELECT 
      c.*,
      (SELECT COUNT(*) FROM jobs WHERE company_id = c.id AND status = 'active') as active_jobs_count
    FROM companies c
    WHERE c.id = ?
  `

  db.get(query, [companyId], (err, company) => {
    if (err) {
      return res.status(500).json({ error: "Database error" })
    }

    if (!company) {
      return res.status(404).json({ error: "Company not found" })
    }

    // Get active jobs for this company
    db.all(
      'SELECT id, title, location, job_type, salary_display, created_at FROM jobs WHERE company_id = ? AND status = "active" ORDER BY created_at DESC',
      [companyId],
      (err, jobs) => {
        if (err) {
          return res.status(500).json({ error: "Database error" })
        }

        res.json({
          ...company,
          active_jobs: jobs,
        })
      },
    )
  })
})

// Update company profile (Company only)
router.put(
  "/profile",
  authenticateToken,
  authorizeCompany,
  [
    body("name").optional().notEmpty().trim(),
    body("industry").optional().trim(),
    body("location").optional().trim(),
    body("tagline").optional().trim(),
    body("about").optional().trim(),
    body("website").optional().isURL(),
    body("employee_count").optional().trim(),
  ],
  (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
    }

    const updateFields = []
    const updateValues = []

    // Build dynamic update query
    Object.keys(req.body).forEach((key) => {
      if (req.body[key] !== undefined) {
        updateFields.push(`${key} = ?`)
        updateValues.push(req.body[key])
      }
    })

    if (updateFields.length === 0) {
      return res.status(400).json({ error: "No fields to update" })
    }

    updateFields.push("updated_at = CURRENT_TIMESTAMP")
    updateValues.push(req.user.id)

    const updateQuery = `UPDATE companies SET ${updateFields.join(", ")} WHERE user_id = ?`

    db.run(updateQuery, updateValues, function (err) {
      if (err) {
        return res.status(500).json({ error: "Failed to update company profile" })
      }

      if (this.changes === 0) {
        return res.status(404).json({ error: "Company profile not found" })
      }

      res.json({ message: "Company profile updated successfully" })
    })
  },
)

// Get company profile (Company only)
router.get("/profile/me", authenticateToken, authorizeCompany, (req, res) => {
  const query = `
    SELECT 
      c.*,
      (SELECT COUNT(*) FROM jobs WHERE company_id = c.id AND status = 'active') as active_jobs_count,
      (SELECT COUNT(*) FROM job_applications ja JOIN jobs j ON ja.job_id = j.id WHERE j.company_id = c.id) as total_applications
    FROM companies c
    WHERE c.user_id = ?
  `

  db.get(query, [req.user.id], (err, company) => {
    if (err) {
      return res.status(500).json({ error: "Database error" })
    }

    if (!company) {
      return res.status(404).json({ error: "Company profile not found" })
    }

    res.json(company)
  })
})

module.exports = router
