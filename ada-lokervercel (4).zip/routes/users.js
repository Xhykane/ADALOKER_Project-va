const express = require("express")
const { body, validationResult } = require("express-validator")
const bcrypt = require("bcryptjs")
const database = require("../config/database")
const { authenticateToken } = require("../middleware/auth")

const router = express.Router()
const db = database.getDb()

// Get user profile
router.get("/profile", authenticateToken, (req, res) => {
  db.get(
    "SELECT id, email, user_type, full_name, phone_number, address, profile_summary, profile_picture, created_at FROM users WHERE id = ?",
    [req.user.id],
    (err, user) => {
      if (err) {
        return res.status(500).json({ error: "Database error" })
      }

      if (!user) {
        return res.status(404).json({ error: "User not found" })
      }

      res.json(user)
    },
  )
})

// Update user profile
router.put(
  "/profile",
  authenticateToken,
  [
    body("full_name").optional().notEmpty().trim(),
    body("phone_number").optional().trim(),
    body("address").optional().trim(),
    body("profile_summary").optional().trim(),
  ],
  (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
    }

    const updateFields = []
    const updateValues = []

    Object.keys(req.body).forEach((key) => {
      if (req.body[key] !== undefined) {
        updateFields.push(`${key} = ?`)
        updateValues.push(req.body[key])
      }
    })

    if (updateFields.length === 0) {
      return res.status(400).json({ error: "No fields to update" })
    }

    updateFields.push("updated_at = CURRENT_TIMESTAMP")
    updateValues.push(req.user.id)

    const updateQuery = `UPDATE users SET ${updateFields.join(", ")} WHERE id = ?`

    db.run(updateQuery, updateValues, (err) => {
      if (err) {
        return res.status(500).json({ error: "Failed to update profile" })
      }

      res.json({ message: "Profile updated successfully" })
    })
  },
)

// Change password
router.put(
  "/change-password",
  authenticateToken,
  [body("current_password").notEmpty(), body("new_password").isLength({ min: 6 })],
  async (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
    }

    const { current_password, new_password } = req.body

    try {
      // Get current user
      db.get("SELECT password FROM users WHERE id = ?", [req.user.id], async (err, user) => {
        if (err) {
          return res.status(500).json({ error: "Database error" })
        }

        if (!user) {
          return res.status(404).json({ error: "User not found" })
        }

        // Verify current password
        const isValidPassword = await bcrypt.compare(current_password, user.password)
        if (!isValidPassword) {
          return res.status(400).json({ error: "Current password is incorrect" })
        }

        // Hash new password
        const hashedNewPassword = await bcrypt.hash(new_password, 10)

        // Update password
        db.run(
          "UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
          [hashedNewPassword, req.user.id],
          (err) => {
            if (err) {
              return res.status(500).json({ error: "Failed to update password" })
            }

            res.json({ message: "Password updated successfully" })
          },
        )
      })
    } catch (error) {
      res.status(500).json({ error: "Server error" })
    }
  },
)

// User experiences endpoints
router.get("/experiences", authenticateToken, (req, res) => {
  db.all(
    "SELECT * FROM user_experiences WHERE user_id = ? ORDER BY created_at DESC",
    [req.user.id],
    (err, experiences) => {
      if (err) {
        return res.status(500).json({ error: "Database error" })
      }
      res.json(experiences)
    },
  )
})

router.post(
  "/experiences",
  authenticateToken,
  [
    body("title").notEmpty().trim(),
    body("company").notEmpty().trim(),
    body("period").notEmpty().trim(),
    body("description").optional().trim(),
  ],
  (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
    }

    const { title, company, period, description } = req.body

    db.run(
      "INSERT INTO user_experiences (user_id, title, company, period, description) VALUES (?, ?, ?, ?, ?)",
      [req.user.id, title, company, period, description],
      function (err) {
        if (err) {
          return res.status(500).json({ error: "Failed to add experience" })
        }

        res.status(201).json({
          message: "Experience added successfully",
          id: this.lastID,
        })
      },
    )
  },
)

// User educations endpoints
router.get("/educations", authenticateToken, (req, res) => {
  db.all(
    "SELECT * FROM user_educations WHERE user_id = ? ORDER BY created_at DESC",
    [req.user.id],
    (err, educations) => {
      if (err) {
        return res.status(500).json({ error: "Database error" })
      }
      res.json(educations)
    },
  )
})

router.post(
  "/educations",
  authenticateToken,
  [
    body("institution").notEmpty().trim(),
    body("degree").notEmpty().trim(),
    body("period").notEmpty().trim(),
    body("description").optional().trim(),
  ],
  (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
    }

    const { institution, degree, period, description } = req.body

    db.run(
      "INSERT INTO user_educations (user_id, institution, degree, period, description) VALUES (?, ?, ?, ?, ?)",
      [req.user.id, institution, degree, period, description],
      function (err) {
        if (err) {
          return res.status(500).json({ error: "Failed to add education" })
        }

        res.status(201).json({
          message: "Education added successfully",
          id: this.lastID,
        })
      },
    )
  },
)

// User skills endpoints
router.get("/skills", authenticateToken, (req, res) => {
  db.all("SELECT * FROM user_skills WHERE user_id = ? ORDER BY created_at DESC", [req.user.id], (err, skills) => {
    if (err) {
      return res.status(500).json({ error: "Database error" })
    }
    res.json(skills)
  })
})

router.post("/skills", authenticateToken, [body("skill_name").notEmpty().trim()], (req, res) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() })
  }

  const { skill_name } = req.body

  db.run("INSERT INTO user_skills (user_id, skill_name) VALUES (?, ?)", [req.user.id, skill_name], function (err) {
    if (err) {
      return res.status(500).json({ error: "Failed to add skill" })
    }

    res.status(201).json({
      message: "Skill added successfully",
      id: this.lastID,
    })
  })
})

router.delete("/skills/:id", authenticateToken, (req, res) => {
  const skillId = req.params.id

  db.run("DELETE FROM user_skills WHERE id = ? AND user_id = ?", [skillId, req.user.id], function (err) {
    if (err) {
      return res.status(500).json({ error: "Failed to delete skill" })
    }

    if (this.changes === 0) {
      return res.status(404).json({ error: "Skill not found" })
    }

    res.json({ message: "Skill deleted successfully" })
  })
})

module.exports = router
