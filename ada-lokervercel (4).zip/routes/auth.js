const express = require("express")
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")
const { body, validationResult } = require("express-validator")
const database = require("../config/database")
const { JWT_SECRET } = require("../middleware/auth")

const router = express.Router()
const db = database.getDb()

// Register endpoint
router.post(
  "/register",
  [
    body("email").isEmail().normalizeEmail(),
    body("password").isLength({ min: 6 }),
    body("user_type").isIn(["jobseeker", "company"]),
    body("full_name").notEmpty().trim(),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { email, password, user_type, full_name } = req.body

      // Check if user already exists
      db.get("SELECT id FROM users WHERE email = ?", [email], async (err, row) => {
        if (err) {
          return res.status(500).json({ error: "Database error" })
        }

        if (row) {
          return res.status(400).json({ error: "User already exists with this email" })
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10)

        // Insert new user
        db.run(
          "INSERT INTO users (email, password, user_type, full_name) VALUES (?, ?, ?, ?)",
          [email, hashedPassword, user_type, full_name],
          function (err) {
            if (err) {
              return res.status(500).json({ error: "Failed to create user" })
            }

            const userId = this.lastID

            // If company, create company profile
            if (user_type === "company") {
              db.run("INSERT INTO companies (user_id, name) VALUES (?, ?)", [userId, full_name], (err) => {
                if (err) {
                  console.error("Failed to create company profile:", err)
                }
              })
            }

            // Generate JWT token
            const token = jwt.sign({ id: userId, email, user_type }, JWT_SECRET, { expiresIn: "7d" })

            res.status(201).json({
              message: "User registered successfully",
              token,
              user: {
                id: userId,
                email,
                user_type,
                full_name,
              },
            })
          },
        )
      })
    } catch (error) {
      res.status(500).json({ error: "Server error" })
    }
  },
)

// Login endpoint
router.post("/login", [body("email").isEmail().normalizeEmail(), body("password").notEmpty()], async (req, res) => {
  try {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
    }

    const { email, password } = req.body

    db.get("SELECT * FROM users WHERE email = ?", [email], async (err, user) => {
      if (err) {
        return res.status(500).json({ error: "Database error" })
      }

      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" })
      }

      // Check password
      const isValidPassword = await bcrypt.compare(password, user.password)
      if (!isValidPassword) {
        return res.status(401).json({ error: "Invalid credentials" })
      }

      // Generate JWT token
      const token = jwt.sign({ id: user.id, email: user.email, user_type: user.user_type }, JWT_SECRET, {
        expiresIn: "7d",
      })

      res.json({
        message: "Login successful",
        token,
        user: {
          id: user.id,
          email: user.email,
          user_type: user.user_type,
          full_name: user.full_name,
          profile_picture: user.profile_picture,
        },
      })
    })
  } catch (error) {
    res.status(500).json({ error: "Server error" })
  }
})

module.exports = router
