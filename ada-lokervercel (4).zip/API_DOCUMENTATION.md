# ADAloker API Documentation

## Base URL
\`\`\`
http://localhost:3001/api
\`\`\`

## Authentication
Most endpoints require authentication using JWT tokens. Include the token in the Authorization header:
\`\`\`
Authorization: Bearer <your_jwt_token>
\`\`\`

## Endpoints

### Authentication

#### POST /auth/register
Register a new user (jobseeker or company)

**Request Body:**
\`\`\`json
{
  "email": "user@gmail.com",
  "password": "password123",
  "user_type": "jobseeker", // or "company"
  "full_name": "John Doe"
}
\`\`\`

**Response:**
\`\`\`json
{
  "message": "User registered successfully",
  "token": "jwt_token_here",
  "user": {
    "id": 1,
    "email": "user@gmail.com",
    "user_type": "jobseeker",
    "full_name": "John Doe"
  }
}
\`\`\`

#### POST /auth/login
Login with email and password

**Request Body:**
\`\`\`json
{
  "email": "user@gmail.com",
  "password": "password123"
}
\`\`\`

**Response:**
\`\`\`json
{
  "message": "Login successful",
  "token": "jwt_token_here",
  "user": {
    "id": 1,
    "email": "user@gmail.com",
    "user_type": "jobseeker",
    "full_name": "John Doe",
    "profile_picture": null
  }
}
\`\`\`

### Jobs

#### GET /jobs
Get all jobs with filtering and pagination

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10, max: 100)
- `search` (optional): Search in title, description, or company name
- `company` (optional): Filter by company name
- `job_type` (optional): Filter by job type (WFO, WFH, Hybrid, WFA)
- `salary_min` (optional): Minimum salary filter
- `salary_max` (optional): Maximum salary filter

**Response:**
\`\`\`json
{
  "jobs": [
    {
      "id": 1,
      "title": "Senior Frontend Developer",
      "location": "Jakarta, Indonesia",
      "job_type": "Hybrid",
      "salary_display": "Rp 15 Juta - 22 Juta",
      "description": "Job description...",
      "company_name": "PT. Teknologi Maju",
      "company_logo": "/path/to/logo.png",
      "applicants_count": 5,
      "created_at": "2024-01-15T09:00:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 25,
    "totalPages": 3
  }
}
\`\`\`

#### GET /jobs/:id
Get job details by ID

**Response:**
\`\`\`json
{
  "id": 1,
  "title": "Senior Frontend Developer",
  "location": "Jakarta, Indonesia",
  "job_type": "Hybrid",
  "salary_display": "Rp 15 Juta - 22 Juta",
  "description": "Detailed job description...",
  "requirements": "Job requirements...",
  "benefits": "Job benefits...",
  "company_name": "PT. Teknologi Maju",
  "company_logo": "/path/to/logo.png",
  "company_description": "Company description...",
  "company_website": "https://company.com",
  "applicants_count": 5,
  "views_count": 45,
  "created_at": "2024-01-15T09:00:00Z"
}
\`\`\`

#### POST /jobs
Create a new job (Company only, requires authentication)

**Request Body:**
\`\`\`json
{
  "title": "Frontend Developer",
  "location": "Jakarta, Indonesia",
  "job_type": "Hybrid",
  "salary_display": "Rp 10 Juta - 15 Juta",
  "salary_min": 10000000,
  "salary_max": 15000000,
  "description": "Job description...",
  "requirements": "Job requirements...",
  "benefits": "Job benefits..."
}
\`\`\`

#### PUT /jobs/:id
Update a job (Company only, requires authentication)

#### DELETE /jobs/:id
Delete a job (Company only, requires authentication)

#### GET /jobs/company/my-jobs
Get company's posted jobs (Company only, requires authentication)

### Companies

#### GET /companies
Get all companies

**Response:**
\`\`\`json
[
  {
    "id": 1,
    "name": "PT. Teknologi Maju Indonesia",
    "industry": "Teknologi Informasi",
    "location": "Jakarta, Indonesia",
    "tagline": "Inovasi untuk Masa Depan Digital",
    "logo": "/path/to/logo.png",
    "active_jobs_count": 3
  }
]
\`\`\`

#### GET /companies/:id
Get company details by ID

#### PUT /companies/profile
Update company profile (Company only, requires authentication)

#### GET /companies/profile/me
Get own company profile (Company only, requires authentication)

### Applications

#### POST /applications
Apply for a job (Jobseeker only, requires authentication)

**Request Body:**
\`\`\`json
{
  "job_id": 1,
  "full_name": "John Doe",
  "email": "john@gmail.com",
  "phone_number": "081234567890",
  "address": "Jakarta",
  "portfolio_link": "https://portfolio.com",
  "additional_info": "Why I'm interested...",
  "expected_salary": 12000000
}
\`\`\`

#### GET /applications/job/:jobId
Get applications for a specific job (Company only, requires authentication)

#### GET /applications/my-applications
Get user's job applications (Jobseeker only, requires authentication)

#### PUT /applications/:id/status
Update application status (Company only, requires authentication)

**Request Body:**
\`\`\`json
{
  "status": "reviewed" // pending, reviewed, shortlisted, rejected, hired
}
\`\`\`

### Users

#### GET /users/profile
Get user profile (requires authentication)

#### PUT /users/profile
Update user profile (requires authentication)

#### PUT /users/change-password
Change password (requires authentication)

#### GET /users/experiences
Get user experiences (requires authentication)

#### POST /users/experiences
Add user experience (requires authentication)

#### GET /users/educations
Get user educations (requires authentication)

#### POST /users/educations
Add user education (requires authentication)

#### GET /users/skills
Get user skills (requires authentication)

#### POST /users/skills
Add user skill (requires authentication)

#### DELETE /users/skills/:id
Delete user skill (requires authentication)

## Error Responses

All endpoints return errors in the following format:

\`\`\`json
{
  "error": "Error message",
  "errors": [
    {
      "field": "email",
      "message": "Invalid email format"
    }
  ]
}
\`\`\`

## Status Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `500` - Internal Server Error

## Getting Started

1. Install dependencies: `npm install`
2. Initialize database: `npm run init-db`
3. Start development server: `npm run dev`
4. API will be available at `http://localhost:3001/api`

## Sample Data

The database comes with sample data including:
- 2 companies
- 3 jobs
- 4 users (2 jobseekers, 2 companies)
- Sample applications

**Sample Login Credentials:**
- Company: `company1@gmail.com` / `password`
- Jobseeker: `jobseeker1@gmail.com` / `password`
