const fs = require("fs")
const path = require("path")
const database = require("../config/database")

const db = database.getDb()

// Create database directory if it doesn't exist
const dbDir = path.join(__dirname, "../database")
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true })
}

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, "../uploads")
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true })
}

console.log("🗄️  Initializing ADAloker database...")

// Read and execute seed data
const seedDataPath = path.join(__dirname, "seed-data.sql")
if (fs.existsSync(seedDataPath)) {
  const seedData = fs.readFileSync(seedDataPath, "utf8")
  const statements = seedData.split(";").filter((stmt) => stmt.trim())

  statements.forEach((statement, index) => {
    if (statement.trim()) {
      db.run(statement, (err) => {
        if (err) {
          console.error(`Error executing statement ${index + 1}:`, err.message)
        }
      })
    }
  })

  console.log("✅ Sample data inserted successfully")
} else {
  console.log("⚠️  Seed data file not found, skipping sample data insertion")
}

setTimeout(() => {
  console.log("🎉 Database initialization completed!")
  console.log("📝 Sample accounts created:")
  console.log("   Company: company1@gmail.com / password")
  console.log("   Jobseeker: jobseeker1@gmail.com / password")
  console.log("   Jobseeker: jobseeker2@gmail.com / password")
  console.log("   Company: company2@gmail.com / password")
  console.log("")
  console.log("🚀 You can now start the server with: npm run dev")

  database.close()
  process.exit(0)
}, 1000)
