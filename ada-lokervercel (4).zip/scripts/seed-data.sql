-- Seed data for ADAloker Database
-- This script inserts sample data for testing

-- Insert sample users
INSERT OR IGNORE INTO users (id, email, password, user_type, full_name, phone_number, created_at) VALUES
(1, 'company1@gmail.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'company', 'PT. Teknologi Maju Indonesia', '021-12345678', '2024-01-01 10:00:00'),
(2, 'jobseeker1@gmail.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'jobseeker', 'Ahmad Rizki Pratama', '081234567890', '2024-01-02 10:00:00'),
(3, 'jobseeker2@gmail.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'jobseeker', 'Sari Dewi Lestari', '081234567891', '2024-01-03 10:00:00'),
(4, 'company2@gmail.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'company', 'Tech Solutions Inc.', '021-87654321', '2024-01-04 10:00:00');

-- Insert sample companies
INSERT OR IGNORE INTO companies (id, user_id, name, industry, location, tagline, about, website, logo, banner, employee_count, created_at) VALUES
(1, 1, 'PT. Teknologi Maju Indonesia', 'Teknologi Informasi', 'Jakarta, Indonesia', 'Inovasi untuk Masa Depan Digital', 'PT. Teknologi Maju Indonesia adalah perusahaan teknologi terdepan yang berfokus pada pengembangan solusi digital inovatif untuk berbagai industri.', 'https://www.teknologimaju.co.id', '/ADAloker_vercel/assets/images/company_logo_sample1.png', '/ADAloker_vercel/assets/images/company_banner_sample1.jpg', '50-200 Karyawan', '2024-01-01 10:00:00'),
(2, 4, 'Tech Solutions Inc.', 'Pendidikan & Teknologi', 'Bandung, Indonesia', 'Solusi Teknologi Pendidikan', 'Tech Solutions Inc. adalah startup EdTech yang berkembang pesat, fokus pada pengembangan platform pembelajaran digital.', 'https://www.techsolutions.co.id', '/ADAloker_vercel/assets/images/company_logo_sample2.png', '/ADAloker_vercel/assets/images/company_banner_sample2.jpg', '20-50 Karyawan', '2024-01-04 10:00:00');

-- Insert sample jobs
INSERT OR IGNORE INTO jobs (id, company_id, title, location, job_type, salary_display, salary_min, salary_max, description, requirements, status, views_count, created_at) VALUES
(1, 1, 'Senior Frontend Developer', 'Jakarta, Indonesia', 'Hybrid', 'Rp 15 Juta - 22 Juta', 15000000, 22000000, 'Kami mencari Senior Frontend Developer yang berpengalaman untuk bergabung dengan tim pengembangan kami. Kandidat ideal memiliki keahlian mendalam dalam React.js, TypeScript, dan modern web technologies.', 'Minimal 4 tahun pengalaman sebagai Frontend Developer, Mahir dalam React.js, TypeScript, HTML5, CSS3', 'active', 45, '2024-01-15 09:00:00'),
(2, 1, 'UI/UX Designer', 'Jakarta, Indonesia', 'WFO', 'Rp 10 Juta - 16 Juta', 10000000, 16000000, 'Bergabunglah dengan tim kreatif kami sebagai UI/UX Designer! Kami mencari individu yang passionate dalam menciptakan pengalaman pengguna yang luar biasa.', 'Minimal 2 tahun pengalaman sebagai UI/UX Designer, Mahir menggunakan Figma, Adobe XD, atau Sketch', 'active', 32, '2024-01-20 09:00:00'),
(3, 2, 'Fullstack Developer', 'Bandung, Indonesia', 'Hybrid', 'Rp 9 Juta - 14 Juta', 9000000, 14000000, 'Tech Solutions Inc. mencari Fullstack Developer untuk mengembangkan platform pembelajaran digital yang inovatif.', 'Pengalaman dengan React.js dan Node.js, Familiar dengan database PostgreSQL/MongoDB', 'active', 28, '2024-01-22 09:00:00');

-- Insert sample job applications
INSERT OR IGNORE INTO job_applications (id, job_id, user_id, full_name, email, phone_number, address, portfolio_link, additional_info, status, applied_at) VALUES
(1, 1, 2, 'Ahmad Rizki Pratama', 'ahmad.rizki@gmail.com', '081234567890', 'Jakarta Selatan', 'https://portfolio.ahmadrizki.com', 'Saya sangat tertarik dengan posisi ini karena sesuai dengan pengalaman saya di bidang frontend development.', 'pending', '2024-01-16 10:30:00'),
(2, 1, 3, 'Sari Dewi Lestari', 'sari.dewi@gmail.com', '081234567891', 'Jakarta Timur', 'https://github.com/saridewi', 'Memiliki pengalaman 5 tahun dalam pengembangan aplikasi web dengan React.js.', 'pending', '2024-01-17 14:20:00'),
(3, 2, 2, 'Ahmad Rizki Pratama', 'ahmad.rizki@gmail.com', '081234567890', 'Jakarta Selatan', 'https://dribbble.com/ahmadrizki', 'Tertarik untuk berkontribusi dalam tim design yang kreatif.', 'pending', '2024-01-21 11:15:00');

-- Insert sample user experiences
INSERT OR IGNORE INTO user_experiences (user_id, title, company, period, description) VALUES
(2, 'Frontend Developer', 'PT. Digital Kreatif', '2022 - 2024', 'Mengembangkan aplikasi web menggunakan React.js dan TypeScript untuk berbagai klien korporat.'),
(2, 'Junior Web Developer', 'CV. Web Solutions', '2020 - 2022', 'Membangun website responsif menggunakan HTML, CSS, JavaScript dan framework Bootstrap.'),
(3, 'UI/UX Designer', 'Startup Teknologi ABC', '2021 - 2024', 'Merancang interface dan user experience untuk aplikasi mobile dan web platform.'),
(3, 'Graphic Designer', 'Freelance', '2019 - 2021', 'Mendesain materi marketing digital untuk berbagai klien UMKM.');

-- Insert sample user educations
INSERT OR IGNORE INTO user_educations (user_id, institution, degree, period, description) VALUES
(2, 'Universitas Indonesia', 'S1 Teknik Informatika', '2016 - 2020', 'Fokus pada pengembangan perangkat lunak dan pemrograman web.'),
(3, 'Institut Teknologi Bandung', 'S1 Desain Komunikasi Visual', '2015 - 2019', 'Spesialisasi dalam desain digital dan user interface design.');

-- Insert sample user skills
INSERT OR IGNORE INTO user_skills (user_id, skill_name) VALUES
(2, 'React.js'),
(2, 'TypeScript'),
(2, 'Node.js'),
(2, 'HTML5'),
(2, 'CSS3'),
(3, 'Figma'),
(3, 'Adobe XD'),
(3, 'Sketch'),
(3, 'Photoshop'),
(3, 'Illustrator');
