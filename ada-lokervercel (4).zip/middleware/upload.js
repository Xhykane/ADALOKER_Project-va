const multer = require("multer")
const path = require("path")
const fs = require("fs")

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, "../uploads")
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true })
}

// Configure storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    let uploadPath = uploadsDir

    // Create subdirectories based on file type
    if (file.fieldname === "cv" || file.fieldname === "cover_letter") {
      uploadPath = path.join(uploadsDir, "documents")
    } else if (file.fieldname === "profile_picture") {
      uploadPath = path.join(uploadsDir, "profiles")
    } else if (file.fieldname === "company_logo" || file.fieldname === "company_banner") {
      uploadPath = path.join(uploadsDir, "companies")
    }

    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true })
    }

    cb(null, uploadPath)
  },
  filename: (req, file, cb) => {
    // Generate unique filename
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9)
    const extension = path.extname(file.originalname)
    cb(null, file.fieldname + "-" + uniqueSuffix + extension)
  },
})

// File filter
const fileFilter = (req, file, cb) => {
  if (file.fieldname === "cv" || file.fieldname === "cover_letter") {
    // Allow PDF, DOC, DOCX for documents
    const allowedTypes = [
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ]
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true)
    } else {
      cb(new Error("Only PDF, DOC, and DOCX files are allowed for documents"), false)
    }
  } else if (
    file.fieldname === "profile_picture" ||
    file.fieldname === "company_logo" ||
    file.fieldname === "company_banner"
  ) {
    // Allow images for pictures
    if (file.mimetype.startsWith("image/")) {
      cb(null, true)
    } else {
      cb(new Error("Only image files are allowed"), false)
    }
  } else {
    cb(new Error("Unexpected field"), false)
  }
}

// Configure multer
const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
})

module.exports = upload
