const jwt = require("jsonwebtoken")
const database = require("../config/database")

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-in-production"

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1] // Bearer TOKEN

  if (!token) {
    return res.status(401).json({ error: "Access token required" })
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: "Invalid or expired token" })
    }
    req.user = user
    next()
  })
}

const authorizeCompany = (req, res, next) => {
  if (req.user.user_type !== "company") {
    return res.status(403).json({ error: "Access denied. Company account required." })
  }
  next()
}

const authorizeJobseeker = (req, res, next) => {
  if (req.user.user_type !== "jobseeker") {
    return res.status(403).json({ error: "Access denied. Jobseeker account required." })
  }
  next()
}

module.exports = {
  authenticateToken,
  authorizeCompany,
  authorizeJobseeker,
  JWT_SECRET,
}
